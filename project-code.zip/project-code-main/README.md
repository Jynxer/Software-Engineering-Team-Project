# project-code
### Dependencies:
- Currently, only functional on gnu-linux and macOS.
- `node.js`: Framework used to run the server.  
  Installation:  
    - Preinstalled on school servers and lab machines.
    - Linux: [Tutorial blog](https://linuxconfig.org/install-npm-on-linux) by Korbin Brown
    - MacOS: If homebrew installed: `brew install node` (or `brew install npm`)  
      Otherwise [This](https://www.newline.co/@Adele/how-to-install-nodejs-and-npm-on-macos--22782681) tutorial blog by Adele Kuzmiakova
    - Windows: If chocolatey installed: `choco install nodejs`  
      Otherwise the [Microsoft documentation](https://docs.microsoft.com/en-us/windows/dev-environment/javascript/nodejs-on-windows) by [mattwojo](https://github.com/mattwojo) is helpful.
    - If all else fails, try the [official node installer](https://nodejs.org/en/download/).
- The node module dependencies are listed in [package-lock.json](./package-lock.json).  
  These should be built when `make`, `make build` or `make .dependencies` is ran.  
  Known error - typescript may not install from these, however. If this occurs, run `npm i typescript`.
- `wget` - should be preinstalled on school servers.
  - MacOS - `brew install wget`
  - Linux - `apt install wget`

### Build instructions
- `make`: installs dependencies, builds, and runs the server.
- `make build`: installs dependencies, and builds the server.
- `make .dependencies`: installs dependencies.
- `make clean`: removes built **.js** files.
- `make clean_database`: removes database install and contents.
- `make allclean`: removes built **.js** files, dependencies and the database.

### Usage instructions (server)
If running locally, use the `make` command to start the server from this directory.  
Navigate to `localhost:22292` to start using the Journal (hosted locally).  
To stop the server, type `quit` into the same terminal you typed the `make` command.  
To remove built files, use the `make allclean` command in this directory.

### Usage instructions (client)
First, you will need to register as a new user. You can do this by using the **Register** button on the navbar on the
top right of your screen.  
Fill in the form, and click **Submit Query**.

You can browse posted code from our journal using the **Journal** button on the navbar on the top left of your screen.  
Click on a particular post to inspect the uploaded code and description.  
You can comment on this code by typing in the comment box. Comments on source code require a line number to comment on.  
You can reply to other comments by clicking the three vertical buttons on the right hand side of your screen next to the comment
 you want to reply to. Then click the message box, and type your reply.  


To upload a submission, click the **Upload** button when logged in. You can select multiple files to upload, or a zip file.  

To browse the posted code from other Journals in our SuperGroup, navigate to **Journal**, and choose the journal you wish to browse with 
the provided drop-down menu.  


To change your user's details, hover over your profile picture on the navbar on the top right of your screen.
Then click the **Details** menu item.  
You can then edit your user's details by clicking the **Edit** button.  
You can change your profile picture by providing a URI to the image. If you want to upload your own, a link to imgur has been provided.  
You can change the name displayed by our server. This will not change the username you use to log in to our server.  
To change your password, click the **Change Password** button. You will need to enter your old password to confirm this.  


To logout, hover over your profile picture on the navbar on the top right of your screen. Then click the **Logout** drop down menu.  

If you want to log in as an Admin user, check the Admin login credentials from when you started your server (using `make`).  
Log in to the UI with these credentials.  

To manage the details of other users, hover over your profile picture in the navbar on the top right of your screen This will only appear 
if you have the permissions to do so. Then click the **Manage Users** menu item.  
This will bring you to the 'Admin' screen. Search for either the user name or uuid of the user you wish to edit. This will accept regex 
queries. You can then click the users that appear to expand their details. 
