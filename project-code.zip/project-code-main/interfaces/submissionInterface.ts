import { Document } from "mongoose";
import { SubmissionStages } from "../routes/permission/submissionStages";
import { ISGUser } from "./userInterface";

// Info passed in about the submissions
export interface ISubmissionInfo {
    title: string;
    description: string;
}

// Data returned from the database
export interface ISubmission extends Document, ISubmissionInfo {
    uuid: string;
    kind: "original" | "migrated";
    authorUuid: string;
    submissionDate: Date; // ISO 8601
    originalUuid?: string;
    originalJournalId?: number;
    versionNumber: number;
    submissionStage: SubmissionStages;
}

// Data required to be returned about a submission for the Supergroup
export interface ISGSubmission {
    uuid: string;
    kind: "original" | "migrated";
    title: string,
    description: string,
    originalUuid?: string;
    originalJournalId?: number;
    authorUuid?: string;
    migratorUuid?: string;
    submissionDate?: Date; // ISO 8601
    migrationDate?: Date; // ISO 8601
}

// Data returned from a path query
export interface ISubmissionPathContents {
    type: "file" | "directory";
    filename: string;
    contents?: string;
    entries?: IDirectoryEntry[]
}

// A directory entry in the file system
export interface IDirectoryEntry {
    type: "file" | "directory",
    filename: string
}

// The permissions a user can have for a submission
export interface IStagePermissions {
    stage: SubmissionStages,
    canUnpublish: boolean,
    canReview: boolean,
    canPublish: boolean
}

export interface ISGPost {
    user: ISGUser;
    submission: ISGSubmission;
}