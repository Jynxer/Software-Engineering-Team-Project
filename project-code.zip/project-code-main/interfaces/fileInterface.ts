// Content of a file to store in the db
export interface IFileContent {
    name: string,
    contents: Buffer
}
