import { Response } from "express";
import { logger } from '../Middleware/loggingMiddleware';

// Some permission errors which can occur
export enum PermissionError {
    BadPermissions = "Not enough Permission",
    NoSuchUuid = "No such uuid",
    CantEdit = "Can't edit",
}

// A general function used as many error messages were very similar
export function sendError(err:string, item: string, res:Response, item_name:string | null = null) {
    let item_str:string = item_name != null ?  item_name : '';
    let user_str: string = res.locals.id ? `User ${res.locals.id}`: 'Not logged in user' ;

    // Need error code for user not signed in
    switch(err) {
        case PermissionError.NoSuchUuid:
            res.status(404).json({
                status: "error",
                message: `${item} not found`
            });
            logger.warn(`${user_str} failed tried to access ${item} ${item_str} which doesn't exist!`);

            return;

        case PermissionError.BadPermissions:
            res.status(403).json({
                status: "error",
                message: `Can't access ${item}`
            });
            logger.warn(`${user_str}  failed to access submission ${item_str} without enough permissions`);
            return;
    
        // No specific error
        default:
            res.status(500).json({
                status: "error",
                message: "Internal server error"
            });
            logger.warn(`Error occurred when searching for ${item} ${item_str}`);
            logger.debug(err);
            return;
        }
}