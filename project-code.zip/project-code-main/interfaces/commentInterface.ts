// Data that the server should be recieving for a comment
export interface ICommentInfo {
    submissionUuid: string;
    path?: string;
    line: number;
    contents: string;
    replyingTo?: string;
}

// Comments to return to supergroup endpoints 
export interface ISGComment {
    uuid: string;
    authorUuid: string;
    commentDate: Date;
    contents: string;
}

export interface ICommentJournal extends ISGComment {
    line: number
}

// Available comment stages
export enum CommentStages {
    Review = "Review",
    Public = "Public",
}


