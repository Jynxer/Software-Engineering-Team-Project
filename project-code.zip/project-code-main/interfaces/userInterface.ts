// Currently needed information for the user
export interface IUserInfo {
    uuid: string;
    username: string;
    email: string;
    fullName: string;
    password: string;
    profilePicture?: string;
}

// Data returned about user to supergroup
export interface ISGUser {
    uuid: string;
    username: string;
    journalId: number;
    fullName: string;
    profilePicUrl: string;
}