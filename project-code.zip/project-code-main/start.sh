#!/bin/bash
# Script to start and reload the server

safeExitStatus=$(./getKey.py config.json safeExitCode 2>&1)
reloadExitStatus=$(./getKey.py config.json pullExitCode 2>&1)

re='^[0-9]+$'

if ! [[ $safeExitStatus =~ $re ]] ; then
  echo "Invalid safe exit status in config.json: $safeExitStatus"
  exit 1;
fi

if ! [[ $reloadExitStatus =~ $re ]] ; then
  echo "Invalid reload exit status in config.json: $reloadExitStatus"
  exit 1;
fi

if ! make build ; then
  echo "Building failed.";
  exit 1;
fi

npx -p node@14 npm start --scripts-prepend-node-path 2> /dev/null

exitStatus=$?

if [ $exitStatus -ne "$safeExitStatus" ]
        then
        echo "Reloading Server..."

        if [ $exitStatus -eq "$reloadExitStatus" ]
                then
                echo "Pulling from repo"
                git pull
        fi
        ./"$0"
else
        echo "Stopping Server."
        make .database_stop
fi
