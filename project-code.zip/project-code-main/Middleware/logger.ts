import * as winston from 'winston';

/**
 * Simple logging class
 *
 * @author 150000946
 */
export class Logger {
    private static colours = {
        error: 'red',
        warn: 'yellow',
        http: 'grey',
        info: 'white',
        debug: 'cyan'
    }

    private static normalFormat = winston.format.combine(
        winston.format.timestamp({format: 'DD-MM-YYYY HH:mm:ss:ms'}),
        winston.format((info) => {
            info.level = info.level.toUpperCase()
            return info;
        })(),
        winston.format.printf(messageInfo => {
            return `[${messageInfo.level}]\t${messageInfo.timestamp.substr(0, 22)} - ${messageInfo.message}`;
        })
    );

    private static colourFormat = winston.format.combine(
        winston.format.timestamp({format: 'DD-MM-YYYY HH:mm:ss'}),
        winston.format((info) => {
            info.level = info.level.toUpperCase()
            return info;
        })(),
        winston.format.printf(messageInfo => {
            return `[${messageInfo.level}]\t${messageInfo.timestamp.substr(0, 22)} - ${messageInfo.message}`;
        }),
        winston.format.colorize({all: true})
    );

    /**
     * The logging levels supported by this logger, in order of precedence.
     *
     * i.e. if `warn` is the current level, the logger will log both `warn` and `error` level logs.
     */
    static levels = {
        error: 0,
        warn: 1,
        info: 2,
        http: 3,
        debug: 4
    }

    private transports: winston.transports.StreamTransportInstance[] = []

    /**
     * Initialises a logger which logs to the given filenames.
     *
     * @param filenames : dictionary of filenames, and the logging level (null if all levels).
     * @param logToConsole : boolean true if logs should also be written to console.
     */
    constructor(filenames: { [key: string]: string | null }, logToConsole: boolean) {
        if (logToConsole) {
            this.transports.push(new winston.transports.Console({format: Logger.colourFormat}));
        }
        Object.keys(filenames).forEach(key => {
            const value: string | null = filenames[key];
            if (value === null) {
                this.transports.push(new winston.transports.File({
                    filename: key,
                    level: "debug",
                    format: Logger.normalFormat
                }));
            } else {
                this.transports.push(new winston.transports.File({
                    filename: key,
                    level: <string>value,
                    format: Logger.normalFormat
                }));
            }
        });
        winston.addColors(Logger.colours);
    }

    /**
     * Returns a logger.
     *
     * @param level : string - must be found in `logger.levels` - otherwise
     * @throws InvalidLevelError
     */
    getLogger(level: string): winston.Logger {
        if (level in Logger.levels) {
            return winston.createLogger({
                level: level,
                levels: Logger.levels,
                format: Logger.normalFormat,
                transports: this.transports
            });
        } else {
            throw new InvalidLevelError(level);
        }
    }
}

/**
 * Simple class to indicate invalid levels.
 */
export class InvalidLevelError extends Error {
    constructor(level: string) {
        super(level);
    }
}
