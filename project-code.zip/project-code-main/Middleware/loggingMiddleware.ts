import * as morgan from 'morgan';

import config = require('../config.json');

import {Logger} from './logger'

// logger setup
const logFiles = {'./logs/server.log': 'http', './logs/error.log': 'warn', './logs/debug.log': null};
export const logger = new Logger(logFiles, config.logToConsole).getLogger(config.loggingLevel);

// middleware for express requests
export const LoggingMiddleware = morgan(
    ":method :url - :remote-addr",
    {
        stream: {
            write: message => logger.http(message.trim())
        }
    });
