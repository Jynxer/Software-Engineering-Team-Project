import { tokenExpired } from './jwtHandling';
import { logger } from './loggingMiddleware';

/**
 * Holds the whitelist of JWT to be invalidated.
 *
 * @author 150000946
 */
export class jwtWhitelist {
    static whitelist: Set<string> = new Set<string>();
    static PANIC_SIZE = 10000;

    static addItem(token: string): void {
        if (this.whitelist.size > this.PANIC_SIZE) {
            this.whitelist.clear();
        }
        this.whitelist.add(token);
        logger.debug(`Token ${token} added to jwt whitelist`);
    }

    static containsItem(token: string): boolean {
        return this.whitelist.has(token);
    }

    static removeItem(token: string): void {
        if (this.containsItem(token)) {
            this.whitelist.delete(token);
        }
    }

    /**
     * Removes invalid tokens from the whitelist - will be found to be invalid by the token itself.
     */
    static purgeAllOld() {
        for (let key of this.whitelist.keys()) {
            if (tokenExpired(key)) {
                this.whitelist.delete(key)
                logger.debug(`Removing old token ${key}`);
            }
        }
    }
}
