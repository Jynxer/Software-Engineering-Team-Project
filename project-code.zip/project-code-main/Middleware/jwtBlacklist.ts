import { tokenExpired } from './jwtHandling';
import { logger } from './loggingMiddleware';

/**
 * Holds the blacklist of JWT to be invalidated.
 *
 * @author 150000946
 */
export class jwtBlacklist {
    static blacklist: Set<string> = new Set<string>();
    static PANIC_SIZE = 10000;

    static addItem(token: string): void {
        if (this.blacklist.size > this.PANIC_SIZE) {
            this.blacklist.clear();
        }
        this.blacklist.add(token);
        logger.debug(`Token ${token} added to jwt blacklist`);
    }

    static containsItem(token: string): boolean {
        return this.blacklist.has(token);
    }

    /**
     * Removes invalid tokens from the blacklist - will be found to be invalid by the token itself.
     */
    static purgeAllOld() {
        for (let key of this.blacklist.keys()) {
            if (tokenExpired(key)) {
                this.blacklist.delete(key)
                logger.debug(`Removing old token ${key}`);
            }
        }
    }
}