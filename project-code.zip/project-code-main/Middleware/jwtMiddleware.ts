import { Request, Response, NextFunction } from 'express';
import { getID, parseTokenID } from './jwtHandling';
import { logger } from './loggingMiddleware';
import { jwtWhitelist } from './jwtWhitelist';

// Handles the validation for token
export function JWTMiddleware(req: Request, res: Response, next: NextFunction) {
    // Checks if it contains the authorization header
    const header = req.header("Authorization");

    if (!header) {
        res.locals.authorised = false;
        next();
    } else {
        parseTokenID(header) // attempts to parse the token
            .then(id => {
                logger.debug(`Parsed ID : ${id}`);
                res.locals.id = id;
                res.locals.authorised = true;
                next();
            })
            .catch(err => {
                jwtWhitelist.purgeAllOld();
                if (jwtWhitelist.containsItem(header)) {
                    getID(header)
                        .then(id => {
                            logger.debug(`Parsed ID : ${id}`);
                            res.locals.id = id;
                            res.locals.authorised = true;
                            next();
                        })
                        .catch((err: any) => {
                            logger.error(`Could not get ID for whitelisted token ${header}: ${err}`);
                            res.locals.authorised = false;
                            next();
                        })
                } else {
                    logger.debug(`Error on parsing JWT: ${err}`)
                    res.locals.authorised = false;
                    next();
                }
            });
    }
}
