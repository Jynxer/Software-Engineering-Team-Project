import * as jwt from 'jsonwebtoken';
import config = require('../config.json');
import supergroup = require('../routes/supergroup.json');
import { jwtBlacklist } from "./jwtBlacklist";
import sanitize = require('mongo-sanitize');

const tokenTTL: number = config.jwtValidDuration;
const secretKey: string = config.jwtSecretKey; // Secret key for token signing

export function genToken(id: string): string {
    return jwt.sign({ iss: config.supergroupID, sub: id }, secretKey, { expiresIn: tokenTTL, algorithm: "HS512" });
}

export function parseTokenID(token: string): Promise<string> {
    let id: string;
    return new Promise<string>((res, rej) => {
        if (jwtBlacklist.containsItem(token)) {
            rej("Token manually expired.");
        }
        try {
            let decodedToken: jwt.JwtPayload = <jwt.JwtPayload>jwt.verify(token, secretKey, { algorithms: ["HS512"] });
            id = <string>decodedToken.sub;
            res(sanitize(id));
        } catch (err) {
            rej(err);
        }
    });
}

export function getIssuer(token: string): Promise<number> {
    return new Promise<number>((res, rej) => {
        try {
            const payload: jwt.JwtPayload = <jwt.JwtPayload>jwt.decode(token, { complete: true });
            const issuer: number = <number>Number(payload.payload.iss);
            if (!Number.isInteger(issuer) || !supergroup.hasOwnProperty(issuer)) {
                rej("issuer is not an integer");
            }
            res(issuer);
        } catch (err: any) {
            rej(err);
        }
    })
}


export function getID(token: string): Promise<string> {
    return new Promise<string>((res, rej) => {
        try {
            const payload: jwt.JwtPayload = <jwt.JwtPayload>jwt.decode(token, { complete: true });
            const uid: string = <string>payload.payload.sub;
            res(uid);
        } catch (err: any) {
            rej(err);
        }
    })
}

export function tokenExpired(token: string): boolean {
    try {
        const payload: jwt.JwtPayload = <jwt.JwtPayload>jwt.decode(token, { complete: true });
        const exp: number = <number>payload.payload.exp;
        return exp < Math.floor(Date.now() / 1000);
    } catch (_) {
        return true;
    }
}
