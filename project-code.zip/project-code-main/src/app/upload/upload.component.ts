import {Component, OnInit} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Router} from '@angular/router'
import {genHeaders} from "../../Authorization";
import { ActivatedRoute, ParamMap } from '@angular/router';


@Component({
    selector: 'app-upload',
    templateUrl: './upload.component.html',
    styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {

    fileToUpload: File | null = null;
    filesToUpload: FileList | null = null;
    postUUID:string | null = null;
    filesString: String = "No files selected";
    submissionTitle: string = '';
    submissionDescription: string = '';
    uploadErr:string = ""
    constructor(private route: ActivatedRoute, private http: HttpClient, private router: Router) {
    }

    ngOnInit(): void {
        this.uploadErr = "";
        this.route.paramMap.subscribe((params: ParamMap) => {
            this.postUUID = params.get('uuid')
          })
      
      
          const token = sessionStorage.getItem("token");
    }

    handleFileInput(event: EventTarget | null) {
        try {
            let inputElement: HTMLInputElement = <HTMLInputElement>event;
            let files: FileList = <FileList>inputElement.files;
            this.filesToUpload = files;
            this.fileToUpload = files.item(0);
            if (files.length == 0) {
                this.filesString = "No files selected";
            } else {
                this.filesString = "";
                for (let i = 0; i < files.length; i++) {
                    let file = <File>files.item(i);
                    this.filesString += file.name;
                    if (i + 1 < files.length) {
                        this.filesString += ", "
                    }
                }
            }
        } catch (err) {
            console.error(`Could not prepare file for upload: ${err}`);
            //TODO: error handle
        }
    }

    postFile() {
        const formData: FormData = new FormData();

        let file: File;

        try {
            for (let i = 0; i < <number>this.filesToUpload?.length; i++) {
                file = <File>(<FileList>this.filesToUpload).item(i);

                formData.append(`file${i}`, file, file.name);
            }
            
            let url:string = "/upload";
            if (this.postUUID) {
                url = "/reupload"
                formData.append("uuid", this.postUUID);
            }
         
            formData.append('title', this.submissionTitle);
            formData.append('description', this.submissionDescription);
            this.http
                .post<any>(url, formData, { headers: genHeaders() })
                .subscribe({
                    next: data => {
                        switch (data.status) {
                            case 'ok':
                                console.log(data);
                                this.router.navigate(['/journal', data.uuid])
                                    .then(() => window.location.reload())
                                    .catch(err => {
                                        console.error(`Could not redirect to journal : ${err}`);
                                        //TODO: error handle
                                    });
                                break;
                            default:
                                console.log("ERROR!!!!");
                            //TODO: error handle
                        }
                    },
                    error: error => {
                        console.error('There was an error!', error);
                        this.uploadErr = error.error.message;
                        //TODO: error handle
                    }
                });
        } catch (err) {
            console.error(`Failed to upload file : ${err}`);
        }

        return;
    }

}
