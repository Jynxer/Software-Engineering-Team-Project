import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Router } from '@angular/router'
import { genHeaders } from "../../Authorization";
import supergroup = require("../../../routes/supergroup.json");
import { KeyValue } from '@angular/common';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    ErrorMessage: string = '';
    supergroups: supergroupInfo = supergroup;
    journalId = "7";

    constructor(private http: HttpClient, private router: Router) {
    }

    ngOnInit(): void {
        this.http.get<any>('/loginAPI/loggedIn', { headers: genHeaders() }).subscribe({
            next: data => {
                let loggedIn: boolean = data.loggedIn;

                if (loggedIn) {
                    this.router.navigate(['/'])
                        .catch(err => {
                            console.error(`An error occurred: ${err}`);
                            //todo: error handle
                        });
                }
            },
            error: error => {
                console.error('There was an error!!', error);
                //todo: error handle
            }
        });
    }

    onClickSubmit(form: any) {
        const body = {
            "username": form.username,
            "password": form.password,
            "journalId": this.journalId
        };
        this.http.post<any>('/v1/login', body, { headers: genHeaders() }).subscribe({
            next: data => {
                switch (data.status) {
                    case 'ok':
                        sessionStorage.setItem('token', data.token);
                        this.ngOnInit();
                        break;
                    default:
                        console.log("ERROR!!!!");
                    //TODO: error handle
                }
            },
            error: error => {
                console.error('There was an error!', error);
                if (!error.error.message) {
                        console.log("Unknown error");
                        this.ErrorMessage = `${error.status}: ${this.supergroups[<number> Number(this.journalId)].name} did not provide an error message`
                        return;
                }
                switch (error.error.message) {
                    case 'missingFields':
                        console.log("Missing fields!");
                        this.ErrorMessage = 'Please enter username and password!';
                        break;
                    case 'invalidCredentials':
                        console.log("Invalid credentials!");
                        this.ErrorMessage = 'Invalid credentials!';
                        break;
                    default:
                        this.ErrorMessage = `${error.status}: ${this.supergroups[Number(this.journalId)].name}: ${error.error.message}`;
                        console.log("ERROR!!!!");
                }
            }
        });
    }

    keyAscOrder = (a: KeyValue<string, any>, b: KeyValue<string, any>): number => {
        const aKey = Number(a.key)
        const bKey = Number(b.key)
        return aKey < bKey ? -1 : (bKey < aKey ? 1 : 0);
    }

}


interface supergroupInfo {
    [key: number]: { name: string, url: string }
}