import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Router } from '@angular/router'
import { get, post } from "../../Authorization";
import { Role } from 'routes/permission/roles';
import { genHeaders } from "../../Authorization";

@Component({
    selector: 'app-navbar',
    templateUrl: './navbar.component.html',
    styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

    data?: any;
    loggedIn?: boolean;
    role?: Role;
    username: string = "";
    page = 'home'
    pfp: string = ""

    constructor(private http: HttpClient, private router: Router) {
    }

    /**
     *  Asks server if the user is logged in. Displays correct messages corresponding to answer.
     */
    ngOnInit(): void {
        this.router.events.subscribe(event => {
            const eventString = event.toString();
            if (eventString.substring(0, eventString.indexOf("(")) === "NavigationEnd") {
                this.loginCheck();
                this.fixNavbar();
            }
        });
        this.loginCheck()
        this.fixNavbar();
    }

    fixNavbar(): void {
        switch (location.pathname) {
            case '/':
                this.updatePage('home');
                break;
            default:
                let s: string = location.pathname;
                this.updatePage(s.substring(1));
        }
    }

    loginCheck(): void {
        this.http.get<any>('/loginAPI/loggedIn', { headers: genHeaders() })
            .subscribe({
                next: data => {
                    let loggedIn: boolean = data.loggedIn;

                    if (loggedIn) {
                        this.loggedIn = true;
                        this.http.get<any>('/loginAPI/getUsername', { headers: genHeaders() })
                            .subscribe({
                                next: res => {
                                    if (res.status === "ok") {
                                        this.username = res.username;
                                        this.pfp = res.pfp;
                                    }
                                },
                                error: _ => {
                                    this.loggedIn = false;
                                    sessionStorage.removeItem("token");
                                    this.username = ""
                                }
                            });
                        post(this.http, '/permissions/get', {}, 
                            res => {
                                if (res.status = "ok") {
                                    this.role = res.role;
                                }
                            },
                            err => {
                                //TODO: error message
                            }
                        );
                    } else {
                        this.loggedIn = false;
                        sessionStorage.removeItem("token");
                        this.username = ""
                    }

                    this.data = data;
                },
                error: error => {
                    console.error('There was an error!', error);
                    if (error.status != 0 && error.statusText != "Unknown Error") {
                        this.data.loggedin = false;
                        sessionStorage.removeItem("token");
                        this.loggedIn = false;
                        this.username = ""
                    }
                }
            });
    }

    updatePage(page: string): void {
        this.page = page;
    }

    logout(): void {
        this.http.post<any>('/logout', {}, { headers: genHeaders() }).subscribe(data => {
            if (data.status === "ok") {
                sessionStorage.removeItem("token");
                window.location.reload();
            }
        });
    }
}
