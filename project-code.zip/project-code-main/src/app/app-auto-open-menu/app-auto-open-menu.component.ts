import {Component} from '@angular/core';

/**
 * Wrapper to mat-menu
 *
 * Sourced from:
 * https://stackoverflow.com/questions/53618333/how-to-open-and-close-angular-mat-menu-on-hover
 *
 * @author Pierre-Henri Sudre <https://stackoverflow.com/users/3804977/pierre-henri-sudre>
 * Modified by 150000946
 */
@Component({
    selector: 'app-auto-open-menu',
    template: `
        <div class="app-nav-item" [matMenuTriggerFor]="menu" #menuTrigger="matMenuTrigger"
             (mouseenter)="mouseEnter(menuTrigger)" (mouseleave)="mouseLeave(menuTrigger)">
            <ng-content select="[trigger]"></ng-content>
        </div>
        <mat-menu #menu="matMenu" [hasBackdrop]="false" xPosition="before">
            <div (mouseenter)="mouseEnter(menuTrigger)" (mouseleave)="mouseLeave(menuTrigger)">
                <ng-content select="[content]"></ng-content>
            </div>
        </mat-menu>
    `
})
export class AutoOpenMenuComponent {
    timedOutCloser: any;

    constructor() {
    }

    mouseEnter(trigger: any) {
        if (this.timedOutCloser) {
            clearTimeout(this.timedOutCloser);
        }
        trigger.openMenu();
    }

    mouseLeave(trigger: any) {
        this.timedOutCloser = setTimeout(() => {
            trigger.closeMenu();
        }, 100);
    }
}