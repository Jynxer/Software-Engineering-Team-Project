import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { get, post } from 'src/Authorization';
import { ISGUser } from '../../../interfaces/userInterface'

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  user: any;
  displayUser: boolean = false;
  authName?: string;
  edit: boolean = false;
  errorMsg?: string;
  editing: boolean[] = [false, false]
  oldPass: string = ""
  newPass: string[] = ["", ""]
  showDefaultPfpButton = false;

  constructor(private http: HttpClient) {
    this.user = {}
  }

  ngOnInit(): void {
    get(this.http, '/loginAPI/user',
      (res: any) => {
        const uid: string = res.uid;
        if (uid) {
          fetch(`/v1/users/${uid}`)
            .then(res => res.json())
            .then((res: any) => {
              if (res.status == "ok") {
                this.user = <ISGUser>res.user;
                this.displayUser = true;
              } else {
                this.errorMsg = `No user with uid ${uid} exists.`;
              }
            })
            .catch((err: any) => {
              this.errorMsg = `Failed to fetch user: ${err.message}`;
            })
            .then(() => {
              get(this.http, '/loginAPI/getAuthname',
                (res: any) => {
                  if (res.status == "ok") {
                    this.authName = res.name
                  } else {
                    this.errorMsg = `No auth user with uid ${uid} exists.`;
                  }
                },
                (err: any) => {
                  this.errorMsg = `Failed to fetch user: ${err.message}`;
                });
            })
        } else {
          this.errorMsg = "Not logged in!"
        }
      },
      (err: any) => {
        this.errorMsg = `Failed to get user: ${err.message}`
      });
  }

  changeEdit(i: number, res: boolean) {
    i = i < 0 ? -i : i;
    i = i % 2;
    this.editing[i] = res;
    if (!res) {
      this.errorMsg = undefined;
    }
  }

  displayPfpErrorMessage() {
    // const image = document.getElementById('pfp-img')
    // if(image.complete && image.naturalHeight !== 0)
    console.log('got here');
    this.showDefaultPfpButton = true;
    
  }

  updatePfpToDefault() {
    this.user.profilePicUrl = "assets/default-pfp.png";

    post(this.http, '/modify/user', this.user,
    (res: any) => {
      if (res.status == "ok") {
        this.changeEdit(0, false);
        this.errorMsg = undefined;
        this.ngOnInit();
        window.location.reload();
      } else {
        this.errorMsg = `Failed to modify user data: ${res.message} `;
      }
    },
    (err: any) => {
      console.log(err)
      this.errorMsg = `Failed to modify user data: ${err.message}`;
    })
}

  checkIfImageIsValid(imageUrl: string) {
    // checks if image is a valid file type
    if (!imageUrl.endsWith('.jpg') &&
    !imageUrl.endsWith('.jpeg') &&
    !imageUrl.endsWith('.gif') &&
    !imageUrl.endsWith('.png')) {
      return false;
    } else {
        return true;
    }
  }



  submitDetails() {
    post(this.http, '/modify/user', this.user,
      (res: any) => {
        if (res.status == "ok") {
          this.changeEdit(0, false);
          this.errorMsg = undefined;
          this.ngOnInit();
          window.location.reload();
        } else {
          this.errorMsg = `Failed to modify user data: ${res.message} `;
        }
      },
      (err: any) => {
        console.log(err)
        this.errorMsg = `Failed to modify user data: ${err.message}`;
      })
  }

  submitPassword() {
    const form: any = {}
    form.old_password = this.oldPass;
    form.new_one = this.newPass[0];
    form.new_two = this.newPass[1];
    if (form.old_password && form.new_one && form.new_two) {
      if (form.new_one == form.new_two) {
        if (form.new_one.length < 8) {
          this.errorMsg = "Passwords must be of length 8 or larger."
          return;
        }
        post(this.http, '/modify/auth', {old: form.old_password, new: form.new_one},
        (res: any) => {
          if (res.status == "ok") {
            this.changeEdit(1, false);
            this.errorMsg = undefined;
          } else {
            this.errorMsg = `Failed to change password: ${res.message}`
          }
        },
        (err: any) => {
          console.log(err)
          this.errorMsg = `Failed to change password: ${err.message}`
        })
      } else {
        this.errorMsg = "New passwords do not match."
      }
    } else {
      let missing = "";
      if (!form.old_password) {
        missing = "current password"
      } else if (!form.new_one) {
        missing = "new password"
      } else {
        missing = "password confirmation"
      }
      this.errorMsg = `Please fill in the ${missing} field.`
    }
  }
}
