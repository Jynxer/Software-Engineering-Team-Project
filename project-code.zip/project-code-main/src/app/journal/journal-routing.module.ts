import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { JournalComponent } from './journal.component';
import { HomeComponent } from '../home/home.component';

import { PostComponent } from '../post/post.component';

const routes: Routes = [
  { path: 'journal', component: JournalComponent },
  { path: 'journal/:uuid/:journalID', component: PostComponent },
  { path: 'journal/:uuid', component: PostComponent },
  { path: '', component: HomeComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class JournalRoutingModule { }
