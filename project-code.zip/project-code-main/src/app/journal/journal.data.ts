import { SubmissionStages } from 'routes/permission/submissionStages';
import { ICommentJournal } from '../../../interfaces/commentInterface';
import { ISGSubmission } from '../../../interfaces/submissionInterface';

export interface Post {
    author: string;
    profilePicture: string;
    content: Submission;
}

interface Submission {
    uuid: string;
    kind: string;
    authorUuid: string;
    title: string;
    description: string;
    submissionDate: Date; // ISO 8601
    stage: SubmissionStages;
    originalUuid?: string;
    originalJournalId?: number;
    reposterUuid?: string;
    repostDate?: Date; // ISO 8601
}

export interface Comment {
    author: string;
    profilePicture: string;
    content: ICommentJournal
}

