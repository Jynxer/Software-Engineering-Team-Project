import { Component, OnInit } from '@angular/core';
import { ISGSubmission } from 'interfaces/submissionInterface';
import { Post } from './journal.data';
import supergroup = require("../../../routes/supergroup.json");
import { KeyValue } from '@angular/common';
import { HttpClient } from "@angular/common/http";
import { get } from "../../Authorization";
import { Router } from '@angular/router';
import { SubmissionStages } from 'routes/permission/submissionStages';

@Component({
    selector: 'app-journal',
    templateUrl: './journal.component.html',
    styleUrls: ['./journal.component.css']
})


export class JournalComponent implements OnInit {

    search: string = '';
    shownPosts: Post[] = [];
    publishedPosts: Post[] = [];
    reviewPosts: Post[] = [];
    unpublishedPosts: Post[] = [];
    selected: string = 'Published';
    journalID = "7";
    showPosts: boolean = false;
    supergroups: supergroupInfo = supergroup;


    constructor(private router: Router, private http: HttpClient) { }

    ngOnInit(): void {
        const token = sessionStorage.getItem("token");

        this.shownPosts = [];
        this.search = '';
        this.showPosts = false;
        this.publishedPosts = [];
        this.reviewPosts = [];
        this.unpublishedPosts = [];


        get(this.http, '/v1/submissions/latest?id=' + this.journalID,
            async data => {
                switch (data.status) {
                    case 'ok':
                        for (let post of data.submissions) {
                            let authorUuid: string;
                            if (post.kind === "repost") {
                                authorUuid = post.migratorUuid;
                            } else {
                                authorUuid = post.authorUuid;
                            }
                            await fetch(`/v1/users/${authorUuid}?id=${this.journalID}`)
                                .then(res => res.json())
                                .then(async res => {
                                    let user = res.user;

                                    if (this.journalID !== "7") {
                                        let newPost: Post = {
                                            author: user.username,
                                            profilePicture: user.profilePicture,
                                            content: {
                                                uuid: post.uuid,
                                                kind: post.kind,
                                                authorUuid: post.authorUuid,
                                                title: post.title,
                                                description: post.description,
                                                submissionDate: post.date, // ISO 8601
                                                stage: SubmissionStages.Published
                                            }
                                        };

                                        this.publishedPosts.push(newPost);
                                        return;
                                    }

                                    get(this.http, `/submission/${post.uuid}/getStage`,
                                        data => {
                                            if (data.status == "ok") {
                                                let newPost: Post = {
                                                    author: user.username,
                                                    profilePicture: user.profilePicture,
                                                    content: {
                                                        uuid: post.uuid,
                                                        kind: post.kind,
                                                        authorUuid: post.authorUuid,
                                                        title: post.title,
                                                        description: post.description,
                                                        submissionDate: post.date, // ISO 8601
                                                        stage: data.stage.stage
                                                    }
                                                };
                                                if (data.stage.stage == SubmissionStages.Published) {
                                                    this.publishedPosts.push(newPost);
                                                } else if (data.stage.stage == SubmissionStages.Reviewing) {
                                                    this.reviewPosts.push(newPost);
                                                } else {
                                                    this.unpublishedPosts.push(newPost);
                                                }
                                            }
                                        },
                                        err => {
                                            //ERR
                                        });


                                });
                        }
                        this.shownPosts = this.publishedPosts;
                        this.showPosts = true;
                }
            }, error => {
                switch (error.error.message) {
                    case "Not logged in":
                        this.router.navigate(['/login']);
                        break;
                    // Unknown error
                    default:


                }
            }
        )
    }

    changeSelection(select: string) {
        this.selected = select;
        if (this.selected == 'Published') {
            this.shownPosts = this.publishedPosts;
        } else if (this.selected == 'Reviewing') {
            this.shownPosts = this.reviewPosts;
        } else {
            this.shownPosts = this.unpublishedPosts;
        }
        this.filter();
    }

    filter() {
        this.shownPosts = [];
        if (this.selected == 'Published') {
            for (let post of this.publishedPosts) {
                // If the search term is in the post
                if (post.content.title.toLowerCase().replace(' ', '').match(`(.)*${this.search.toLowerCase()}(.)*`)) {
                    this.shownPosts.push(post);
                }
            }
        } else if (this.selected == 'Reviewing') {
            for (let post of this.reviewPosts) {
                // If the search term is in the post
                if (post.content.title.toLowerCase().replace(' ', '').match(`(.)*${this.search.toLowerCase()}(.)*`)) {
                    this.shownPosts.push(post);
                }
            }
        } else {
            for (let post of this.unpublishedPosts) {
                // If the search term is in the post
                if (post.content.title.toLowerCase().replace(' ', '').match(`(.)*${this.search.toLowerCase()}(.)*`)) {
                    this.shownPosts.push(post);
                }
            }
        }
    }

    keyAscOrder = (a: KeyValue<string, any>, b: KeyValue<string, any>): number => {
        const aKey = Number(a.key)
        const bKey = Number(b.key)
        return aKey < bKey ? -1 : (bKey < aKey ? 1 : 0);
    }

}
interface supergroupInfo {
    [key: number]: { name: string, url: string }
}
