import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { JournalRoutingModule } from './journal-routing.module';
import { FormsModule } from '@angular/forms';
import { PostComponent } from '../post/post.component';
import { JournalComponent } from './journal.component';
import { HighlightModule } from 'ngx-highlightjs';
import { HttpClientModule } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon'
import { MatRippleModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatExpansionModule } from '@angular/material/expansion'
import { MatInputModule } from '@angular/material/input'
import { MatMenuModule } from '@angular/material/menu'

@NgModule({
  declarations: [
    JournalComponent,
    PostComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    JournalRoutingModule,
    HighlightModule,
    HttpClientModule,
    MatIconModule,
    MatExpansionModule,
    MatRippleModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    MatInputModule,
    MatMenuModule,
  ]
})
export class JournalModule { }
