import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Router } from '@angular/router'
import { genHeaders } from "../../Authorization";

@Component({
    selector: 'app-register',
    templateUrl: './register.component.html',
    styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

    ErrorMessage: string = '';

    constructor(private http: HttpClient, private router: Router) {
    }

    ngOnInit(): void {
        this.http.get<any>('/loginAPI/loggedIn', { headers: genHeaders() }).subscribe({
            next: data => {
                let loggedIn: boolean = data.loggedIn;

                if (loggedIn) {
                    this.router.navigate(['/'])
                        .catch(err => {
                            console.error(`An error occurred: ${err}`);
                            //todo: error handle
                        });
                }
            },
            error: error => {
                console.error('There was an error!', error);
                //todo: error handle
            }
        });
    }

    onClickSubmit(form: any) {
        const body = {
            "username": form.username,
            "password": form.password,
            "email": form.email,
            "fullName": form.fullName
        };
        this.http.post<any>('/register', body).subscribe({
            next: data => {
                switch (data.status) {
                    case 'ok':
                        sessionStorage.setItem('token', data.token);
                        this.ngOnInit();
                        break;
                    default:
                        console.log("ERROR!!!!");
                    //TODO: error handle
                }
            },
            error: error => {
                console.error('There was an error!', error);
                switch (error.error.status) {
                    case 'missingFields':
                        console.log("Missing fields!");
                        this.ErrorMessage = 'Please enter username, password, full name, and email!';
                        break;
                    case 'badPasswordLength':
                        console.log("Invalid password length!");
                        this.ErrorMessage = 'Password must be between 8 and 64 characters!';
                        break;
                    case 'badEmail':
                        console.log("Invalid email address!");
                        this.ErrorMessage = 'Email address invalid!';
                        break;
                    case 'repeatCredentials':
                        console.log("Username or email already in use!");
                        this.ErrorMessage = 'Username or email taken!';
                        break;
                    default:
                        console.log("ERROR!!!!");
                    //TODO: error handle
                }
                //TODO: error handle
            }
        });
    }

}
