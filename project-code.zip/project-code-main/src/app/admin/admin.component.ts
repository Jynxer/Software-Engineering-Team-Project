import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Role } from 'routes/permission/roles';
import { post } from 'src/Authorization';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  users?: any;
  searchTypes: string[] = ["name", "uuid"]
  userName: string[] = [];
  roleOpts = [Role.Editor, Role.Reviewer, Role.Author, Role.Viewer, Role.Mute, Role.Banned]
  roles: Role[] = []
  type: string = "name";
  limit: number = 10;
  myRole?: Role;
  supergroups: number[] = [1, 4, 7, 10, 14, 16, 19, 22, 25]
  supergroup: number[] = [];

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    post(this.http, '/permissions/get', {},
      (data) => {
        if (data.status == "ok") {
          this.myRole = data.role;
        }
      },
      (err) => {
        console.log(err)
      })
  }

  modifyRole(user: any, i: number): void {
    post(this.http, '/permissions/update',
      { uuid: user.uuid, role: this.roles[i] },
      (data) => {
        if (data.status == "ok") {
          user.role = this.roles[i];
        }
      },
      (err) => {
        console.log("ERROR!")
        console.log(err);
      })
  }

  changeJournal(user: any, i: number): void {
    let tempUser: any = user;
    tempUser.journalId = this.supergroup[i];
    post(this.http, '/modify/user', tempUser,
      (res) => {
        if (res.status == "ok") {
          user.journalId = this.supergroup[i]
          console.log("Reassigned!")
        }
      },
      (err) => {
        console.log("Error!")
        console.log(err)
      })

  }

  changeUser(user: any, i: number): void {
    let tempUser: any = user;
    tempUser.username = this.userName[i];
    post(this.http, '/modify/user', tempUser,
      (res) => {
        if (res.status == "ok") {
          user.username = this.userName[i]
          console.log("Reassigned!")
        }
      },
      (err) => {
        console.log("Error!")
        console.log(err)
      })

  }

  onClickSubmit(form: any) {
    form.type = this.type;
    form.limit = this.limit;
    fetch('/v1/users/search/' + encodeURIComponent(form.search) + '?type=' + form.type + '&limit=' + form.limit)
      .then(res => res.json())
      .then(res => {
        if (res.status == "ok") {
          return res.users;
        } else {
          return []
        }
      })
      .then(async users => {
        let lst: any[] = []
        const myValue = await fetch(`/permissions/numeric/${this.myRole}`)
          .then(res => res.json())
          .then(res => {
            if (res.status = "ok") {
              return res.value
            } else {
              return 100;
            }
          })
          .catch(_ => {
            return 100;
          })
        for (let i = 0; i < users.length; i++) {
          let theirValue = await fetch(`/permissions/numeric/${users[i].role}`)
            .then(res => res.json())
            .then(res => {
              if (res.status = "ok") {
                return res.value
              } else {
                return 100;
              }
            })
            .catch(_ => {
              return 100;
            })
          if (myValue < theirValue) {
            lst.push(users[i]);
          }

        }
        return lst;
      })
      .then(users => {
        this.users = users
        this.roles = [];
        this.supergroup = [];
        this.userName = [];
        for (let i = 0; i < users.length; i++) {
          this.roles.push(users[i].role);
          this.userName.push(users[i].username)
          this.supergroup.push(users[i].journalId)
        }
      })
  }
}
