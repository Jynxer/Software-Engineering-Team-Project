import {Component, OnInit} from '@angular/core';
import { submissions } from 'routes/supergroup/submissions';
import {ISGPost} from '../../../interfaces/submissionInterface';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

    posts: ISGPost[] = [];

    constructor() {
    }

    ngOnInit(): void {
        this.posts = [];
        fetch('/v1/submissions/latest?take=10')
            .then(res => res.json())
            .then(res => {
                for (let submission of res.submissions) {
                    fetch('/v1/users/' + submission.authorUuid)
                        .then(res => res.json())
                        .then(res => {
                            this.posts.push({
                                user: res.user,
                                submission: submission
                            })
                        });
                }
            });
    }
}
