import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Router } from '@angular/router';
import { Location } from "@angular/common";
import { Post, Comment } from '../journal/journal.data';
import { FileTree } from './post.data';
import config = require('../../../config.json');
import { HttpClient } from "@angular/common/http";

import { get, post } from "../../Authorization";
import { SubmissionStages } from '../../../routes/permission/submissionStages';
import { IStagePermissions } from '../../../interfaces/submissionInterface';


@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})


export class PostComponent implements OnInit {

  postUUID: string | null = '';
  journalID: string | null = '';
  post!: Post;
  stageDesc: string = '';
  content: string = '';
  line: string = '';
  linesPlaceholder: string = '';
  contentSplit!: string[];
  commentedLines!: boolean[];
  showMalformedLineFieldError!: boolean;
  lineFieldErrorExtension: string = '';
  loggedIn?: boolean = false;
  onHome: boolean = true;
  rootFolder: FileTree = {
    name: 'root',
    path: '/',
    isFile: false,
    children: [],
    resolvedComments: [],
    comments: []
  };
  selectedFile: FileTree = this.rootFolder;
  replyTo?: Comment;
  showResolved: boolean = false;
  stage: IStagePermissions = {
    stage: SubmissionStages.Unpublished,
    canUnpublish: false,
    canReview: false,
    canPublish: false
  }

  // Not used for SG posts;
  edit: boolean = true;
  versionNumber: number = 1;
  version: number = 1;
  versionQueryStr: string = "";
  url: string;
  migrationError: boolean = false;
  downloadLink: string = "";

  constructor(private route: ActivatedRoute, private http: HttpClient, private router: Router, private _location: Location) {
    this.url = route.snapshot.url.join('/');
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.postUUID = params.get('uuid');
      this.journalID = params.get('journalID');
    })

    if (!this.journalID) {
      this.journalID = String(config.supergroupID);
    }
    this.migrationError = false;
    this.downloadLink = `v1/download/${this.journalID}/${this.postUUID}`
    if (this.journalID !== "7") {
      this.edit = false;
    }

    this.rootFolder = {
      name: 'root',
      path: '/',
      isFile: false,
      children: [],
      resolvedComments: [],
      comments: []
    };

    this.selectedFile = this.rootFolder;

    this.post = {
      author: "res",
      profilePicture: "",
      content: {
        uuid: "",
        kind: "original",
        authorUuid: "",
        title: "",
        description: "",
        submissionDate: new Date(0),
        stage: SubmissionStages.Published
      }
    }


    const token = sessionStorage.getItem('token');

    if (token != null) { // guess!
      this.loggedIn = true;
    }
    this.replyTo = undefined;
    this.rootFolder.resolvedComments = [];
    get(this.http, `/v1/submissions/${this.postUUID}?id=${this.journalID}${this.versionQueryStr}`,

      data => {
        let postData = data.submission
        let authorUuid: string;
        if (postData.kind === "repost") {
          authorUuid = postData.migratorUuid;
        } else {
          authorUuid = postData.authorUuid;
        }


        fetch(`/v1/users/${authorUuid}?id=${this.journalID}`)
          .then(res => res.json())
          .then(res => {
            // Incase of migrated post

            this.post = {
              author: res.user.username,
              profilePicture: res.user.profilePicUrl,
              content: {
                uuid: postData.uuid,
                kind: postData.kind,
                authorUuid: authorUuid,
                title: postData.title,
                description: postData.description,
                submissionDate: postData.date, // ISO 8601
                stage: SubmissionStages.Unpublished
              }
            }
          });

        this.createFileTree(this.rootFolder);
        get(this.http, this.edit ? `/${this.postUUID}/comments/?id=${this.journalID}${this.versionQueryStr}` : `/v1/submissions/${this.postUUID}/comments/?id=${this.journalID}${this.versionQueryStr}`,
          async data => {
            for (let commentsFetched of data.comments) {
              let commentThread: any[];
              if (this.edit) {
                commentThread = commentsFetched;
              }
              else { // SG doesn't do
                commentThread = [commentsFetched];
              }
              let comments: any[] = [];
              for (let comment of commentThread) {
                await fetch(`/v1/users/${comment.authorUuid}?id=${this.journalID}${this.versionQueryStr}`)
                  .then(res => res.json())
                  .then(res => {
                    comments.push({
                      author: res.user.username,
                      profilePicture: res.user.profilePicUrl,
                      content: comment
                    });
                  });
              }
              this.rootFolder.comments!.push(comments);
            }
          }, err => {
            // Err
          })

        // Fetches the resolved threads

        if (!this.edit) { // Don't fetch resolved comments for SG
          return;
        }
        get(this.http, `/${this.postUUID}/resolved-comments/`,
          async data => {
            this.rootFolder.resolvedComments = []

            for (let commentThread of data.comments) {
              let resolvedThread: any[] = [];
              for (let comment of commentThread) {
                await fetch(`/v1/users/${comment.authorUuid}?id=${this.journalID}${this.versionQueryStr}`)
                  .then(res => res.json())
                  .then(res => {
                    resolvedThread.push({
                      author: res.user.username,
                      profilePicture: res.user.profilePicUrl,
                      content: comment
                    });
                  });
              }
              this.rootFolder.resolvedComments.push(resolvedThread);
            }
            this.rootFolder.comments!.sort((a, b) => { return a[0].content.line - b[0].content.line });
          },
          err => {
            //ERR
          })

        // Try to fetch submission stage if possible
        get(this.http, `/submission/${this.postUUID}/getStage`,
          data => {
            if (data.status == "ok") {
              this.stage = data.stage;
              this.setStageDesc(this.stage.stage);
            }
          },
          err => {
            // ERR
          })


        // Only fetch onces as unlikey to change versions often
        if (this.versionNumber == 1) {
          get(this.http, `/submission/${this.postUUID}/version`,
            data => {
              if (data.status == "ok") {
                this.versionNumber = data.version;
                if (this.version == 1) {
                  this.version = this.versionNumber;
                }
              }
            },
            err => {
              // ERR
            })
        }
      }, err => {
        if (this.loggedIn) {
          this.router.navigate(['/']);
          return;
        }
        this.router.navigate(['/login']);

      });


  }

  createFileTree(root: FileTree) {
    let path: string = `${root.path}${root.path === '/' ? "" : "/"}?id=${this.journalID}${this.versionQueryStr}`

    get(this.http, `/v1/submissions/${this.postUUID}/contents${path}`,
      rootData => {
        for (const fileData of rootData.submissionPathContents.entries) {
          if (fileData.filename == '.DS_Store' || fileData.filename.startsWith('._')) continue;

          if (fileData.type.toLowerCase() === 'file') {

            let newChild: FileTree;
            if (root.path == '/') {
              get(this.http, `/v1/submissions/${this.postUUID}/contents/${fileData.filename}?id=${this.journalID}${this.versionQueryStr}`,
                data => {
                  newChild = {
                    name: fileData.filename,
                    path: '/' + fileData.filename,
                    isFile: true,
                    children: [],
                    comments: [],
                    resolvedComments: [],
                    content: data.submissionPathContents.contents,
                    contentSplit: data.submissionPathContents.contents.split('\n')
                  }
                  root.children!.push(newChild);

                  get(this.http, (this.edit ? `/${this.postUUID}/comments/${fileData.filename}` : `/v1/submissions/${this.postUUID}/comments/${fileData.filename}`) + `?id=${this.journalID}` + this.versionQueryStr,
                    async data => {
                      for (let commentsFetched of data.comments) {
                        let commentThread: any[];
                        if (this.edit) {
                          commentThread = commentsFetched;
                        }
                        else { // SG doesn't do
                          commentThread = [commentsFetched];
                        }
                        let comments: any[] = [];
                        for (let comment of commentThread) {
                          await fetch(`/v1/users/${comment.authorUuid}?id=${this.journalID}`)
                            .then(res => res.json())
                            .then(res => {
                              comments.push({
                                author: res.user.username,
                                profilePicture: res.user.profilePicUrl,
                                content: comment
                              });
                            });

                        }
                        newChild.comments!.push(comments);
                      }
                    }, err => {
                      // ERR
                    })

                  if (!this.edit) { // Don't fetch resolved comments for SG
                    return;
                  }

                  get(this.http, `/${this.postUUID}/resolved-comments/${fileData.filename}?id=${this.journalID}`,
                    async data => {
                      for (let commentThread of data.comments) {
                        let resolvedThread: any[] = [];
                        for (let comment of commentThread) {
                          await fetch(`/v1/users/${comment.authorUuid}?id=${this.journalID}`)
                            .then(res => res.json())
                            .then(res => {
                              resolvedThread.push({
                                author: res.user.username,
                                profilePicture: res.user.profilePicUrl,
                                content: comment
                              });
                            });
                        }
                        newChild.resolvedComments!.push(resolvedThread);
                      }
                      newChild.comments!.sort((a, b) => { return a[0].content.line - b[0].content.line });
                    },
                    err => {

                    })
                }, err => {
                  //ERR
                })
            } else {
              get(this.http, `/v1/submissions/${this.postUUID}/contents${root.path}/${fileData.filename}?id=${this.journalID}${this.versionQueryStr}`,
                data => {
                  newChild = {
                    name: fileData.filename,
                    path: root.path + '/' + fileData.filename,
                    isFile: true,
                    children: [],
                    comments: [],
                    resolvedComments: [],
                    content: data.submissionPathContents.contents,
                    contentSplit: data.submissionPathContents.contents.split('\n')
                  }
                  root.children!.push(newChild);

                  get(this.http, (this.edit ? `/${this.postUUID}/comments${root.path}/${fileData.filename}` : `/v1/submissions/${this.postUUID}/comments${root.path}/${fileData.filename}`) + `?id=${this.journalID}` + this.versionQueryStr,
                    async data => {

                      for (let commentsFetched of data.comments) {
                        let commentThread: any[];
                        if (this.edit) {
                          commentThread = commentsFetched;
                        }
                        else { // SG doesn't do
                          commentThread = [commentsFetched];
                        }
                        let comments: any[] = [];
                        for (let comment of commentThread) {
                          await fetch(`/v1/users/${comment.authorUuid}?id=${this.journalID}`)
                            .then(res => res.json())
                            .then(res => {
                              comments.push({
                                author: res.user.username,
                                profilePicture: res.user.profilePicUrl,
                                content: comment
                              });
                            });
                        }
                        newChild.comments!.push(comments);
                      }

                      if (!this.edit) { // Don't fetch resolved comments for SG
                        return;
                      }


                      get(this.http, `/${this.postUUID}/resolved-comments${root.path}/${fileData.filename}`,
                        async data => {
                          for (let commentThread of data.comments) {
                            let resolvedThread: any[] = [];
                            for (let comment of commentThread) {
                              await fetch(`/v1/users/${comment.authorUuid}?id=${this.journalID}`)
                                .then(res => res.json())
                                .then(res => {
                                  resolvedThread.push({
                                    author: res.user.username,
                                    profilePicture: res.user.profilePicUrl,
                                    content: comment
                                  });
                                });
                            }
                            newChild.resolvedComments!.push(resolvedThread);
                          }
                          newChild.comments!.sort((a, b) => { return a[0].content.line - b[0].content.line });
                        },
                        err => {
                          // ERR
                        })
                    }, err => {
                      // ERR
                    })
                }, err => {
                  //ERR
                })
            }

          } else {
            let newChild: FileTree;
            if (root.path == '/') {
              newChild = {
                name: fileData.filename,
                path: '/' + fileData.filename,
                isFile: false,
                children: []
              };
            } else {
              newChild = {
                name: fileData.filename,
                path: root.path + '/' + fileData.filename,
                isFile: false,
                children: []
              };
            }

            root.children!.push(newChild);
            this.createFileTree(newChild);
          }

        }
      }, err => {

      })

  }

  changeFile(file: FileTree) {
    this.selectedFile = file;
    this.setLinesPlaceholderAndErrorExtension(this.selectedFile.contentSplit!.length);
    this.showMalformedLineFieldError = false;
  }

  onClickSource() {
    this.onHome = false;
    if (this.selectedFile == this.rootFolder) {
      for (let child of this.rootFolder.children) {
        if (child.isFile) {
          this.selectedFile = child;
          this.setLinesPlaceholderAndErrorExtension(this.selectedFile.contentSplit!.length);
          this.showMalformedLineFieldError = false;
          return;
        }
      }
    }
    for (let child of this.rootFolder.children) {
      if (!child.isFile) {
        for (let subChild of child.children) {
          if (subChild.isFile) {
            this.selectedFile = subChild;
            this.setLinesPlaceholderAndErrorExtension(this.selectedFile.contentSplit!.length);
            this.showMalformedLineFieldError = false;
            return;
          }
        }
      }
    }
  }

  onClickSubmit() {
    let body: { line: any; contents: any; submissionUuid?: string; path?: string; replyingTo?: string; };
    if (this.onHome) {
      body = {
        "contents": this.content,
        "submissionUuid": this.post.content.uuid,
        "path": "/",
        "line": "",
        "replyingTo": this.replyTo ? this.replyTo.content.uuid : ""
      };
    } else {
      body = {
        "contents": this.content,
        "submissionUuid": this.post.content.uuid,
        "path": this.selectedFile.path,
        "line": this.line,
        "replyingTo": this.replyTo ? this.replyTo.content.uuid : ""
      };
    }
    if ((/[^\d]/.test(this.line) || !Number.isInteger(parseInt(this.line)) || (parseInt(this.line) <= 0) || (parseInt(this.line) > this.selectedFile.contentSplit!.length)) && (body.line != "")) {
      this.showMalformedLineFieldError = true;
      return;
    }
    if (this.line == '') {
      body.line = -1;
    }

    post(this.http, '/comment', body,
      commentData => {
        this.content = '';
        this.line = '';
        // We add the comment to the array instead to save us re-fetching the page
        get(this.http, '/loginAPI/getUsername/',
          userData => {

            let newComment: Comment = {
              author: (<any>userData).username,
              profilePicture: (<any>userData).pfp,
              content: {
                uuid: (<any>commentData).uuid,
                authorUuid: '', // Don't need to fill this in for displaying so we leave it
                commentDate: new Date(Date.now()),
                contents: body.contents,
                line: parseInt(body.line)
              }
            }
            if (this.onHome) {
              // Is a reply to another comment
              if (this.replyTo) {
                for (let commentThread of this.rootFolder.comments!) {
                  if (commentThread[0].content.uuid === this.replyTo.content.uuid) {
                    commentThread.push(newComment);
                    break;
                  }
                }
              }
              else {
                this.rootFolder.comments!.push([newComment]);
              }
            } else {
              // Is a reply to another comment
              if (this.replyTo) {
                for (let commentThread of this.selectedFile.comments!) {
                  if (commentThread[0].content.uuid === this.replyTo.content.uuid) {
                    commentThread.push(newComment);
                    break;
                  }
                }
              }
              else {
                this.selectedFile.comments!.push([newComment]);
              }

            }
          }, err => {
            // ERR
          })
      },
      error => {
        console.error('There was an error!', error);
        //TODO: error handle
      })
  }

  // When clicking reply to a comment
  reply(comment: Comment, el: HTMLElement) {
    if (!this.edit) { // Can't reply on non-editable submission
      return;
    }

    this.replyTo = comment;

    el.scrollIntoView({ behavior: 'smooth' });
    return;
  }

  lineHasComment(line: number) {
    for (let j = 0; j < this.selectedFile.comments!.length; j++) {
      if (this.selectedFile.comments![j][0].content.line == line + 1) {
        return (true);
      }
    }
    return (false);
  }

  setLinesPlaceholderAndErrorExtension(lines: number) {
    if (lines == 0) {
      this.linesPlaceholder = "";
      this.lineFieldErrorExtension = "";
    } else if (lines == 1) {
      this.linesPlaceholder = "1";
      this.lineFieldErrorExtension = "(1)";
    } else {
      this.linesPlaceholder = "(1-" + this.selectedFile.contentSplit!.length + ")";
      this.lineFieldErrorExtension = "between 1 and " + this.selectedFile.contentSplit!.length;
    }
  }

  didModify() {
    let line = (<HTMLInputElement>document.getElementById('line')).value
    if ((/[^\d]/.test(line) || !Number.isInteger(parseInt(line)) || (parseInt(line) <= 0) || (parseInt(line) > this.selectedFile.contentSplit!.length)) && (line != "")) {
      this.showMalformedLineFieldError = true;
    } else {
      this.showMalformedLineFieldError = false;
    }
  }

  // When resolving comments
  resolve(comment: Comment) {
    if (!this.edit) { // Can't resolve on non-editable submission
      return;
    }

    let body = {
      uuid: comment.content.uuid
    }
    post(this.http, '/comment/resolve', body,
      data => {
        // Find the resolved comment in the list
        if (this.onHome) {
          for (let commentThread of this.rootFolder.comments!) {
            if (commentThread[0].content.uuid === comment.content.uuid) {
              this.rootFolder.comments!.splice(this.rootFolder.comments!.indexOf(commentThread), 1);

              // Inserts it into the place into the array
              let index = 0;
              for (let resolvedComment of this.rootFolder.resolvedComments!) {
                if (resolvedComment[0].content.commentDate > comment.content.commentDate) {
                  break;
                }
                index++;
              }
              this.rootFolder.resolvedComments!.splice(index, 0, commentThread);

              break;
            }
          }
        } else {
          for (let commentThread of this.selectedFile.comments!) {
            if (commentThread[0].content.uuid === comment.content.uuid) {
              this.selectedFile.comments!.splice(this.selectedFile.comments!.indexOf(commentThread), 1);

              // Inserts it into the place into the array
              let index = 0;
              for (let resolvedComment of this.selectedFile.resolvedComments!) {
                if (resolvedComment[0].content.commentDate > comment.content.commentDate) {
                  break;
                }
                index++;
              }
              this.selectedFile.resolvedComments!.splice(index, 0, commentThread);

              break;
            }
          }
        }
      },
      err => {
        //ERR
      })
  }


  changeStage(newStage: SubmissionStages) {
    let body = {
      "submissionUuid": this.postUUID,
      "newStage": newStage
    }
    post(this.http, '/submission/changeStage', body,
      data => {
        if (this.stage) {
          this.ngOnInit();
          this.stage.stage = newStage;
          this.setStageDesc(newStage);
        }
      },
      error => { }
    )

  }

  unpublish() {
    this.changeStage(SubmissionStages.Unpublished);
  }

  review() {
    this.changeStage(SubmissionStages.Reviewing);
  }

  publish() {
    this.changeStage(SubmissionStages.Published);
  }

  setStageDesc(stage: SubmissionStages) {
    if (stage == SubmissionStages.Published) {
      this.stageDesc = '';
    } else if (stage == SubmissionStages.Reviewing) {
      this.stageDesc = ' - in review';
    } else {
      this.stageDesc = ' - unpublished';
    }
  }

  // For unresolving comments
  unresolve(comment: Comment) {
    if (!this.edit) { // Can't unresolve on non-editable submission
      return;
    }
    let body = {
      uuid: comment.content.uuid
    }
    post(this.http, 'comment/unresolve', body,
      data => {
        // Find unresolved comment in the list
        if (this.onHome) {
          for (let resolvedComment of this.rootFolder.resolvedComments!) {
            if (resolvedComment[0].content.uuid === comment.content.uuid) {
              this.rootFolder.resolvedComments!.splice(this.rootFolder.resolvedComments!.indexOf(resolvedComment), 1);
              // Inserts it into the place into the array

              let index = 0;
              for (let commentThread of this.rootFolder.comments!) {
                if (commentThread[0].content.commentDate > comment.content.commentDate) {
                  break;
                }
                index++;
              }

              this.rootFolder.comments!.splice(index, 0, resolvedComment);
              break;
            }
          }
        } else {
          for (let resolvedComment of this.selectedFile.resolvedComments!) {
            if (resolvedComment[0].content.uuid === comment.content.uuid) {
              this.selectedFile.resolvedComments!.splice(this.selectedFile.resolvedComments!.indexOf(resolvedComment), 1);
              // Inserts it into the place into the array

              let index = 0;
              for (let commentThread of this.selectedFile.comments!) {
                if (commentThread[0].content.commentDate > comment.content.commentDate) {
                  break;
                }
                index++;
              }

              this.selectedFile.comments!.splice(index, 0, resolvedComment);
              break;
            }
          }
        }

      },
      error => {
        console.error('There was an error!', error);
        //TODO: error handle
      })
  }

  migrate(journalID: string | null, submissionUuid: string | null) {
    if (!journalID || !submissionUuid) {
      return;
    }

    get(this.http, `/v1/migrate/${this.journalID}/${this.postUUID}`,
      data => {
        console.log(data);

        this.router.navigate(['/journal', data.uuid])
      },
      err => {
        console.log("ERr:" + err);
        this.migrationError = true;
      })
  }

  getVersion() {
    if (this.version && this.version !== this.versionNumber) {
      this.versionQueryStr = `&version=${this.version}`;
    }
    else {
      this.versionQueryStr = "";
    }
    this.downloadLink += this.versionQueryStr;
    this.ngOnInit();
  }

  goBack() {
    this._location.back();
  }

}
