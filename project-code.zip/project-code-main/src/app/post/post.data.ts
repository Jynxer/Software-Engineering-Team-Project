import { Comment } from "../journal/journal.data";

export interface FileTree {
    name: string;
    path: string;
    isFile: boolean;
    children: FileTree[];
    comments?: Comment[][];
    resolvedComments?: Comment[][];
    content?: string;
    contentSplit?: string[];
}