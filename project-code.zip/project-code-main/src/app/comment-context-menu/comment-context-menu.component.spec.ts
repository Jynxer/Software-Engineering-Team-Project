// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { CommentContextMenu } from './comment-context-menu.component';

// describe('AppAutoOpenMenuComponent', () => {
//   let component: CommentContextMenu;
//   let fixture: ComponentFixture<CommentContextMenu>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [ CommentContextMenu ]
//     })
//     .compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(CommentContextMenu);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
