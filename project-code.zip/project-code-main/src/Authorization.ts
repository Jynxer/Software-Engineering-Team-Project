import { HttpClient, HttpHeaders } from "@angular/common/http";

/**
 * Generates the appropriate headers to be used for JWT authentication.
 */
export function genHeaders(): HttpHeaders {
    const token = sessionStorage.getItem("token");
    if (token == null) {
        return new HttpHeaders({});
    } else {
        return new HttpHeaders({
            "Authorization": token
        });
    }
}

export function get(http: HttpClient, path: string, call: (res: any) => void, fail: (err: any) => void) {
    http.get<any>(path, { headers: genHeaders() }).subscribe({
        next: res => {
            call(res);
        },
        error: err => {
            fail(err.error);
        }
    });
}

export function post(http: HttpClient, path: string, data: any, call: (res: any) => void, fail: (err: any) => void) {
    http.post<any>(path, data, { headers: genHeaders() }).subscribe({
        next: res => {
            call(res);
        },
        error: err => {
            fail(err.error);
        }
    });
}
