import { ICommentJournal, ISGComment, CommentStages } from '../../interfaces/commentInterface';
import { Schema, Document } from 'mongoose';
import {getUserModel, UserConnection} from '../../database/userdb';
const User = getUserModel(UserConnection);


export interface IComment extends Document {
    uuid: string
    authorUuid: string;
    commentDate: Date;
    submissionUuid: string;
    path: string; 
    line: number;
    contents: string;
    stage: CommentStages;
    parentComment: string;
    resolved: boolean;
    versionNumber: number;
}

// Schema to store submission details
export const CommentSchema = new Schema<IComment>({
    uuid: { type: String, required: true, unique: true },
    authorUuid: { type: String, required: true },
    path: { type: String, required: true},
    commentDate: { type: Date, required: true }, // ISO 8601
    submissionUuid: { type: String, required: true},
    line: { type: Number, required: true },
    contents: { type: String, required: true },
    stage: {
        type: String,
        required: true,
        enum: Object.values(CommentStages),
        default: CommentStages.Review,
        get: (role: string | number) => {
            return (<any>CommentStages)[role]
        }
    },
    parentComment: { type: String },
    resolved: {type: Boolean, required: true, default: false},
    versionNumber: { type: Number, required: true }
});


// Format incase schema changes
CommentSchema.methods.formatSG = function(): ISGComment {
    return {
        uuid: this.uuid,
        authorUuid: this.authorUuid,
        commentDate: this.commentDate,
        contents: this.contents
    }
}

// Format incase schema changes so we always - for our journal
CommentSchema.methods.format = function(): ICommentJournal {
    return {
        uuid: this.uuid,
        authorUuid: this.authorUuid,
        commentDate: this.commentDate,
        contents: this.contents,
        line: this.line
    }
}
