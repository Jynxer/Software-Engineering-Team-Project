import { Schema } from 'mongoose';
import { ISGSubmission, ISubmission } from '../../interfaces/submissionInterface';
import { SubmissionStages } from '../../routes/permission/submissionStages';
import { Role } from '../../routes/permission/roles'

import { userHasPermissions } from '../../routes/permission/permissionUtils'

const NotLoggedIn:string = "Not logged in";
// Schema to store submission details
export const SubmissionSchema = new Schema<ISubmission>({
    uuid: { type: String, required: true, unique: true },
    kind: { type: String, required: true },
    authorUuid: { type: String, required: true },
    title: { type: String, required: true },
    description: { type: String, required: true },
    submissionDate: { type: Date, required: true }, // ISO 8601
    originalUuid: { type: String },
    originalJournalId: { type: Number },
    versionNumber: { type: Number, required: true, default: 1 },
    submissionStage: {
        type: String,
        required: true,
        enum: Object.values(SubmissionStages),
        default: SubmissionStages.Unpublished,
        get: (submissionStage: string | number) => {
            return (<any>SubmissionStages)[submissionStage]
        }
    }
});

SubmissionSchema.methods.format = function():ISGSubmission {
    let submission:ISGSubmission = {
        uuid: this.uuid,
        kind: this.kind,
        description: this.description,
        title: this.title,
    }

    if (this.kind === "original") {
        submission.authorUuid = this.authorUuid;
        submission.submissionDate = this.submissionDate;
        return submission;
    }

    submission.originalUuid = this.originalUuid;
    submission.originalJournalId = this.originalJournalId;
    submission.migrationDate = this.submissionDate;
    submission.migratorUuid = this.authorUuid;
    return submission;
}


/**
 * Checks if teh submission can be viewed by the user
 * @param submission to check
 * @param uuid of the user
 * @returns Promise whether they can access or not
 */
async function checkPermsView(submission:any, uuid:string):Promise<boolean> {

    // If user is author or submission is public
    if (submission.authorUuid === uuid) {
        return new Promise<boolean>((res, rej) =>  {
            res(true);
        });
    }

    // We need to check uuid as permission util doesn't like undefined uuid
    if (!uuid) {
        // Can only access if it is published
        return new Promise<boolean>((res, rej) =>  {
            res(submission.submissionStage === SubmissionStages.Published);
        });
    }

    switch(submission.submissionStage) {
        case SubmissionStages.Published:
            return new Promise<boolean>((res, rej) =>  {
                res(true);
            });
        case SubmissionStages.Reviewing:
            return await userHasPermissions(uuid, [Role.Reviewer]);

        case SubmissionStages.Unpublished:
            return await userHasPermissions(uuid, [Role.Admin]);
    }

    return new Promise<boolean>((res, rej) =>  {
        rej('Failed to get permissions');
    });
}