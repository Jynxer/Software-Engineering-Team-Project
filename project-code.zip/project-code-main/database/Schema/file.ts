import { Schema, Document } from 'mongoose';
import {getUserModel, UserConnection} from '../../database/userdb';
const User = getUserModel(UserConnection);

export interface IFileInfo {
    submissionUuid: string,
    path: string,
    isFile: boolean,
    content?: string
    versionNumber: number
}

export interface IFile extends Document, IFileInfo {}


export const FileSchema = new Schema<IFile>({
    path: { type: String, ref: User, required: true },
    submissionUuid: { type: String, required: true },
    isFile: { type: Boolean, required: true },
    content: { type: String},
    versionNumber: {type: Number, required: true},
});

FileSchema.virtual('fileName').get(function(this:any) {

    // Replacing trailing / as this causes issues for files
    let pathsSegments = this.path.replace(/\/$/,'').split('/');
    let fileName:string = <string>pathsSegments.pop();

    // If it is a file, fileName would be blank 
    // if (this.path.endsWith('/')) {
    //     fileName += '/';
    // }
    return fileName
})

FileSchema.index({ path: 1, submissionUuid: 1, versionNumber: 1 }, { unique: true })


