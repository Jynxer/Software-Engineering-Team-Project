import {Schema, Document} from 'mongoose'
import bcrypt = require('bcrypt');
import config = require('../../config.json');

export interface IAuth extends Document {
    uuid: string;
    username: string;
    password: string;
}

// Schema user to store user details
export const AuthSchema = new Schema<IAuth>({
    uuid: {type: String, required: true, unique: true},
    username: {type: String, required: true, unique: true, index: true},
    password: {type: String, required: true}
});

// Ensures that the password is hashed before being saved
AuthSchema.pre('save', function (next) {
    let user = this;
    if (!user.isModified('password')) return next();
    // Hash the password before storing it

    bcrypt.hash(user.password, config.hashComplexity).then((hash: string) => {
        user.password = hash;
        next();
    });
});

// Checks the password against the one store for the user
// callback returns error or whether it managed to find password
AuthSchema.methods.comparePassword = async function (password: string, callback: any) {
    await bcrypt.compare(password, this.password).then((result: boolean) => {
        callback(null, result);
    }).catch((err: any) => {
        callback(err);
    });
};
