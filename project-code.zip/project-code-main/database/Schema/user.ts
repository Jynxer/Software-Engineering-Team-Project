import mongoose = require('mongoose');
import { ISGUser, IUserInfo } from '../../interfaces/userInterface';
import { Role } from '../../routes/permission/roles';
import config = require('../../config.json')

export interface IUser extends mongoose.Document {
    uuid: string;
    username: string;
    email: string;
    fullName: string;
    password: string;
    profilePicture: string;
    role: Role;
    journalId: number;
}

// Schema user to store user details
export const UserSchema = new mongoose.Schema<IUser>({
    uuid: {type: String, required: true, unique: true, index: true},
    username: {type: String, required: true},
    fullName: {type: String, required: true},
    email: {type: String},
    role: {
        type: String,
        required: true,
        enum: Object.values(Role),
        default: Role.Viewer,
        get: (role: string | number) => {
            return (<any>Role)[role]
        }
    },
    // Who doesn't love a cute dog 
    profilePicture: { type: String, default: 'https://material.angular.io/assets/img/examples/shiba2.jpg', required: true},
    journalId: {type: Number, required: true, default: config.supergroupID},
});

UserSchema.index({email: 1, journalId: 1}, {unique: true});
UserSchema.index({uuid: 1, journalId: 1}, {unique: true});

UserSchema.methods.format = function():ISGUser {
    return {
        uuid: this.uuid,
        username: this.username,
        journalId: config.supergroupID,
        fullName: this.fullName,
        profilePicUrl: this.profilePicture
    }
}
