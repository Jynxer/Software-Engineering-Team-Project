import mongoose = require('mongoose');
import { CommentSchema } from './Schema/comment';
import { SubmissionSchema } from './Schema/submission';
import { FileSchema } from './Schema/file';
import config = require('../config.json');
import { logger } from "../Middleware/loggingMiddleware";

const submissionModelName = 'submission';
const fileModelName = 'file';
const commentModelName = 'comment';

function getContentConnection() {
    const conn = mongoose.createConnection(`mongodb://localhost:${config.databasePort}/contents`, config.databaseCredentials);
    conn.model(submissionModelName, SubmissionSchema);
    conn.model(fileModelName, FileSchema);
    conn.model(commentModelName, CommentSchema);

    conn.on('error', (err) => {
        logger.error(`Mongodb error on UserConnection: ${err} - exiting.`);
        process.exit(config.safeExitCode);
    });
    conn.on('disconnected', () => {
        logger.error(`UserConnection disconnected from Mongodb`);
    });
    conn.on('reconnected', () => {
        logger.info(`UserConnection reconnected to Mongodb!`)
    });
    return conn;
}

export function getSubmissionModel(connection: mongoose.Connection): mongoose.Model<{}> {
    return connection.model(submissionModelName);
}

export function getFileModel(connection: mongoose.Connection): mongoose.Model<{}> {
    return connection.model(fileModelName);
}


export function getCommentModel(connection: mongoose.Connection): mongoose.Model<{}> {
    return connection.model(commentModelName);
}


export const contentConnection = getContentConnection();