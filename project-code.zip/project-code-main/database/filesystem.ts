import { IFile, IFileInfo } from "./Schema/file";
import expressFileUpload = require('express-fileupload');
import {v4 as uuidv4} from 'uuid';
import {logger} from "../Middleware/loggingMiddleware";
import yauzl = require('yauzl');
import content = require('../database/filedb');
import { IFileContent } from "../interfaces/fileInterface";

const File = content.getFileModel(content.contentConnection);


// Plan - addAll needed files to map
// when adding a file, we look up the path in the map to see its parents uuid
// making it easier to create

function createFile(path:string, submissionUuid: string, content: string = "", version: number): IFileInfo {
    // If we can get the path, then it already exists 
    
    let pathStr = '/' +  path;

    let file:IFileInfo = {
        submissionUuid: submissionUuid,
        path: pathStr,
        isFile: false,
        versionNumber: version
    };


    // Isn't a directory
    if (!path.endsWith('/')) {
        file.content = content;
        file.isFile = true;
    }

    return file;

}

async function addFile(file: IFileContent, submissionUuid:string, version: number):Promise<IFileInfo[]> {
    return new Promise<IFileInfo[]>((res, rej) => {

        if (file.name.endsWith('.zip')) {
            // Opens the zip file
            
            let files: IFileInfo[] = [];

            let minPathLength:number | null = null;
            let minPath:string[] = [];
            yauzl.fromBuffer(<Buffer>file.contents, {lazyEntries: true}, function (err: Error | undefined, zipfile: yauzl.ZipFile | undefined) {
                // Failed to open zip file
                if (err || !zipfile) {
                    rej('Failed to unzip');
                    return;
                }

                // Starts reading the zip file
                zipfile.readEntry();
                zipfile.on("entry", async function (entry) {
                    // Zip files start with fileName/.. so we remove it
                    let path: string = entry.fileName;
                    let pathSegments:string[] = path.replace(/\/$/,'').split('/');
                    if (minPathLength == null || pathSegments.length < minPathLength) {
                        minPathLength = pathSegments.length;
                        minPath = pathSegments;
                    } 

                    // Returns as issue with migrated submisisons
                    if (!path) {
                        zipfile.readEntry();
                        return;
                    }

                    if (path.endsWith('/')) {
                        files.push(createFile(path, submissionUuid, '', version));
                        zipfile.readEntry();
                        return;
                    }
        
                        // Read the entry
                    zipfile.openReadStream(entry, (err, readStream) => {

                        let fileData: string = "";
                        if (err || !readStream) {
                            return;
                        }

                        readStream.on("data", function (chunk) {
                            fileData += chunk.toString();
                        });

                        readStream.on("end", async function () {
                            files.push(createFile(path, submissionUuid, fileData, version));
                            zipfile.readEntry();
                        });
                    });
                    
                });

                zipfile.on('end', () => {
                    // If we find that the path length is at least 2, it means we need the zip folder as a dir
                    // This arrises when zipping the folder, and not its children
                    if (minPathLength && minPathLength >= 2) {
                        files.push(createFile(minPath[0] + '/', submissionUuid, '', version ));
                    }

                    res(files);
                    zipfile.close();
                })
            });
        } else {
            // Else we create a new array of just a single file
            res([createFile(file.name, submissionUuid, file.contents.toString(), version)])
        }
    })
}


export async function uploadFiles(files: IFileContent[], submissionUuid: string, version: number):Promise<IFileInfo[]> {

        // We add a root file so that 
        let filesToSave: IFileInfo[] = [{
            submissionUuid: submissionUuid,
            path: '/',
            isFile: false,
            versionNumber: version
        }]

        for (let file of files) {
            let newFiles: IFileInfo[] = <IFileInfo[]> await addFile(file, submissionUuid, version);
            filesToSave = filesToSave.concat(newFiles);
        }

        return new Promise<IFileInfo[]>((res,rej) => {
            res(filesToSave);
        })
        // return await File.insertMany(filesToSave);
}


export async function uploadExpressFiles(files: expressFileUpload.FileArray, submissionUuid: string, version: number):Promise<IFileInfo[]> {

    let filesContent:IFileContent[] = [];

    for (let key of Object.keys(files)) {
        let expressFile:expressFileUpload.UploadedFile = <expressFileUpload.UploadedFile>files[key];

        filesContent.push({
            name: expressFile.name,
            contents: Buffer.from(expressFile.data)
        });
    };

    return await uploadFiles(filesContent, submissionUuid, version);
}
