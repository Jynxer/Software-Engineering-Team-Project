import mongoose = require('mongoose');
import {IAuth, AuthSchema} from './Schema/auth';
import config = require('../config.json');
import {logger} from "../Middleware/loggingMiddleware";

export const modelName = 'Auth';

function getAuthConnection() {
    const conn = mongoose.createConnection(`mongodb://localhost:${config.databasePort}/auth`, config.databaseCredentials);
    conn.model(modelName, AuthSchema);

    conn.on('error', (err) => {
        logger.error(`Mongodb error on AuthConnection: ${err} - exiting.`);
        process.exit(config.safeExitCode);
    });
    conn.on('disconnected', () => {
        logger.error(`AuthConnection disconnected from Mongodb`);
    });
    conn.on('reconnected', () => {
        logger.info(`AuthConnection reconnected to Mongodb!`)
    });
    return conn;
}

export function getAuthModel(connection: mongoose.Connection): mongoose.Model<IAuth, any, any, any> {
    return connection.model(modelName);
}

export const AuthConnection = getAuthConnection();