import content = require('../filedb');

import { PermissionError } from "../../interfaces/permissions";
const Comment = content.getCommentModel(content.contentConnection);
import  mongoose = require('mongoose');
import { checkPermsEditByUuid, checkPermsViewByUuid } from './submission';
import { IComment } from '../Schema/comment';
import { SubmissionStages } from '../../routes/permission/submissionStages';
import { CommentStages } from '../../interfaces/commentInterface';

/**
 * Helper function used to see if a user can 'edit' a comment (resolve, reply) by a uuid
 * @param commentUuid the comment to check
 * @param userID the users uuid
 * @returns a promise representing if they can edit or not
 */
async function checkCommentEditByUuid(commentUuid:string, userID:string):Promise<boolean> {
    return await Comment.findOne({uuid: commentUuid})
        .then(async comment => {
            return await checkPermsEditByUuid((<IComment>comment).submissionUuid, userID);
        })
    }


/**
 * Wrapper function used to execute mongoose queries for comments whilst checking permissions (accessing)
 * it will often rej instead of returning false so you can see what went wrong
 * @param query what to search for
 * @param userID the uuid of the user
 * @returns a comment if it can find one, else a rejection with a reason
 */
export async function commentFindOne(query:mongoose.FilterQuery<{}>, userID: string):Promise<IComment> {

    return await Comment.findOne(query).then(comment => {
        return new Promise<IComment>(async (res, rej) => {
            if (!comment) {
                rej(PermissionError.NoSuchUuid)
                return;
            }
            let canAccess:boolean = await checkPermsViewByUuid((<IComment>comment).submissionUuid, userID);
            if (!canAccess) {
                rej(PermissionError.BadPermissions);
                return;
            }
           res(<IComment>comment);
        })
    })
}

/**
 * Wrapper function used to execute mongoose queries for getting one comment whilst checking permissions (editing)
 * it will often rej instead of returning false so you can see what went wrong
 * @param query what to search for
 * @param userID the uuid of the user
 * @returns a comment if it can find one, else a rejection with a reason
 */
export async function commentUpdateOne(query:mongoose.FilterQuery<{}>, update:mongoose.UpdateQuery<{}>, userID: string):Promise<IComment> {
    return Comment.findOne(query)
    .then(comment => {
        return new Promise<IComment>(async (res, rej) => {
            if (!comment) {
                rej(PermissionError.NoSuchUuid);
                return;
            }

            try {
                let canEdit: boolean = await checkPermsEditByUuid((<IComment>comment).submissionUuid, userID);
                if (!canEdit) {
                    rej(PermissionError.CantEdit);
                    return;
                }
                res(comment.update(update));
                return;
            } catch(e) {
                rej(PermissionError.CantEdit);
            }
        })
    })
}

/**
 * Returns the submission stage which the comment stage is mapped to
 * @param submissionStage the submission stage to check
 * @returns the corresponding comment stage
 */
export function getCommentStage(submissionStage: SubmissionStages):CommentStages | null {

    switch(submissionStage) {
        case SubmissionStages.Published:
            return CommentStages.Public
        case SubmissionStages.Reviewing:
            return CommentStages.Review;
        // Has no comments associated with it
        default:
            return null;
    }
}