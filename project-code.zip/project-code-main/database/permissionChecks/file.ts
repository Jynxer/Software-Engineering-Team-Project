// import content = require('../filedb');

// import { PermissionError } from "../../interfaces/permissions";
// const Comment = content.getCommentModel(content.contentConnection);
// const File = content.getFileModel(content.contentConnection);
// const Submission = content.getSubmissionModel(content.contentConnection);
// import  mongoose = require('mongoose');
// import { IFile } from "../Schema/file";
// import { checkPermsEditByUuid, checkPermsViewByUuid } from './submission';




// /**
//  * Wrapper function used to execute mongoose queries for getting one file whilst checking permissions (accessing)
//  * it will often rej instead of returning false so you can see what went wrong
//  * @param query what to search for
//  * @param userID the uuid of the user
//  * @returns a file if it can find one, else a rejection with a reason
//  */
// export async function fileFindOneAccess(query:mongoose.FilterQuery<{}>, userID: string):Promise<IFile> {

//     return await File.findOne(query)
//     .then(async file => {
//         if (!file) {
//             return new Promise<IFile>(async (res, rej) => {
//                 rej(PermissionError.NoSuchUuid);
//             });
//         }
//         let canAccess:boolean = await checkPermsViewByUuid((<IFile>file).submissionUuid, userID);

//         if (!canAccess) {
//             return new Promise<IFile>(async (res, rej) => {
//                 rej(PermissionError.BadPermissions);
//             });
//         }
//         return new Promise<IFile>(async (res, rej) => {
//             res(<IFile>file);
//         });
//     })
// }

// /**
//  * Wrapper function used to execute mongoose queries for getting one file whilst checking permissions (editing)
//  * it will often rej instead of returning false so you can see what went wrong
//  * @param query what to search for
//  * @param userID the uuid of the user
//  * @returns a file if it can find one, else a rejection with a reason
//  */
// export async function fileFindOneEdit(query:mongoose.FilterQuery<{}>, userID: string):Promise<IFile> {

//     return await File.findOne(query)
//     .then(async file => {
//         if (!file) {
//             return new Promise<IFile>(async (res, rej) => {
//                 rej(PermissionError.NoSuchUuid);
//             });
//         }
//         let canAccess:boolean = await checkPermsEditByUuid((<IFile>file).submissionUuid, userID);

//         if (!canAccess) {
//             return new Promise<IFile>(async (res, rej) => {
//                 rej(PermissionError.BadPermissions);
//             });
//         }
//         return new Promise<IFile>(async (res, rej) => {
//             res(<IFile>file);
//         });
//     })
// }



// // /**
// //  * Helper function used to check a file by a given file uuid to see if a u
// //  * @param fileUuid 
// //  * @param userID 
// //  * @returns 
// //  */
// // export async function checkFileViewByUuid(fileUuid:string, userID:string):Promise<boolean> {
// //     return await File.findOne({uuid: fileUuid})
// //         .then(async file => {
// //             return await checkPermsViewByUuid((<IFile>file).submissionUuid, userID);
// //         })
// //  }