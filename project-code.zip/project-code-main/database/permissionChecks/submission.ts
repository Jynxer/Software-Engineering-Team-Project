import { ISGSubmission, IStagePermissions, ISubmission } from "../../interfaces/submissionInterface";
import content = require('../filedb');
import { SubmissionStages } from '../../routes/permission/submissionStages';
import { userHasPermissions } from '../../routes/permission/permissionUtils'

import { Role } from '../../routes/permission/roles'
import { PermissionError } from "../../interfaces/permissions";
const Comment = content.getCommentModel(content.contentConnection);
const File = content.getFileModel(content.contentConnection);
const Submission = content.getSubmissionModel(content.contentConnection);
import mongoose = require('mongoose');


/**
 * Checks if the submission can be viewed by the user
 * @param submission to check
 * @param uuid of the user
 * @returns Promise whether they can access or not
 */
export async function checkPermsView(submission: ISubmission, uuid: string): Promise<boolean> {

    // If user is author or submission is public
    if (submission && submission.authorUuid === uuid) {
        return new Promise<boolean>((res, rej) => {
            res(true);
        });
    }

    // We need to check uuid as permission util doesn't like undefined uuid
    if (!uuid) {
        // Can only access if it is published
        return new Promise<boolean>((res, rej) => {
            res(submission.submissionStage === SubmissionStages.Published);
        });
    }

    if (submission) {
        switch (submission.submissionStage) {
            case SubmissionStages.Published:
                return new Promise<boolean>((res, rej) => {
                    res(true);
                });
            case SubmissionStages.Reviewing:
                return await userHasPermissions(uuid, [Role.Reviewer]);

            case SubmissionStages.Unpublished:
                return await userHasPermissions(uuid, [Role.Admin]);
        }
    }

    return new Promise<boolean>((res, rej) => {
        rej('Failed to get permissions');
    });
}

/**
 * Checks if the submission can be edited by the user
 * @param submission to check
 * @param uuid of the user
 * @returns Promise whether they can edit or not
 */
export async function checkPermsEdit(submission: ISubmission, uuid: string): Promise<boolean> {

    if (submission) {
        // If user is author or submission is public
        if (submission.authorUuid === uuid) {
            return new Promise<boolean>((res, rej) => {
                res(true);
            });
        }

        switch (submission.submissionStage) {
            case SubmissionStages.Published:
                return await userHasPermissions(uuid, [Role.Editor]);
                
            case SubmissionStages.Reviewing:
                return await userHasPermissions(uuid, [Role.Reviewer]);

            case SubmissionStages.Unpublished:
                return await userHasPermissions(uuid, [Role.Admin]);
        }
    }

    return new Promise<boolean>((res, rej) => {
        rej('Failed to get permissions');
    });
}

/**
 * Checks if the submission stage can be changed by a user
 * @param submission to check
 * @param uuid of the user
 * @returns Promise whether they can change it or not
 */
export async function checkPermsChangeStage(submission: ISubmission, uuid: string): Promise<IStagePermissions> {
    let stage: SubmissionStages = <SubmissionStages>submission.submissionStage;
    let isAuthor: boolean = (submission.authorUuid == uuid);


    let isEditor: boolean;
    try {
        isEditor = await userHasPermissions(uuid, [Role.Editor])
    } catch (e) {
        isEditor = false; // Not logged in
    }

    let perms: IStagePermissions = {
        stage: stage,
        canUnpublish: isAuthor || isEditor,
        canReview: isAuthor || isEditor,
        canPublish: isEditor,
    };

    return new Promise((res, rej) => {
        res(perms)
    });

}

/**
 * Helper function used to see if a user can view a submission by a uuid
 * @param submissionUuid the submission to check
 * @param userID the users uuid
 * @returns a promise representing if they can edit or not
 */
export async function checkPermsViewByUuid(submissionUuid: string, userID: string): Promise<boolean> {

    return await Submission.findOne({ uuid: submissionUuid })
        .then(async submission => {
            return await checkPermsView(<ISubmission>submission, userID);
        })
}

/**
 * Helper function used to see if a user can edit a submission by a uuid
 * @param submissionUuid the submission to check
 * @param userID the users uuid
 * @returns a promise representing if they can edit or not
 */
export async function checkPermsEditByUuid(submissionUuid: string, userID: string): Promise<boolean> {
    return await Submission.findOne({ uuid: submissionUuid })
        .then(async submission => {
            return await checkPermsEdit(<ISubmission>submission, userID);
        })
}

/**
* Helper function used to see if a user can change the stage of a submission
* @param submissionUuid the submission to check
* @param userID the users uuid
* @returns a promise representing if they can change the stage or not. This is a json object representing if the given user can
* set the submission to published, reviewing and unpublished - good for backend checsk as well as front end
*/
export async function checkPermsChangeStageByUuid(submissionUuid: string, userID: string): Promise<IStagePermissions> {
    return await Submission.findOne({ uuid: submissionUuid })
        .then(async submission => {
            return await checkPermsChangeStage(<ISubmission>submission, userID);
        })

}


/**
 * Wrapper function used to execute mongoose queries for submission whilst checking permissions (accessing)
 * it will often rej instead of returning false so you can see what went wrong
 * @param query what to search for
 * @param userID the uuid of the user
 * @param skip how many submissions to skip - can omit - default 0
 * @param take how many submissions to take - can omit - default 0
 * @param order how to order the submission - can omit - default no order
 * @returns submisisons if it can find any, else a rejection with a reason
 */
export async function findManyAccess(query: mongoose.FilterQuery<{}>, userID: string, skip: number = 0, take: number = 0, order: any = {}): Promise<ISGSubmission[]> {

    return Submission.find(query)
        .skip(skip)
        .limit(take)
        .sort(order)
        .then(async submissions => {
            let filteredSubmissions: ISGSubmission[] = [];
            for (let submission of submissions) {
                let canAccess: boolean = await checkPermsView(<any>submission, userID);
                if (canAccess) {
                    filteredSubmissions.push((<any>submission).format())
                }
            }
            return filteredSubmissions;
        })
}

/**
 * Wrapper function used to execute mongoose queries for getting a submission whilst checking permissions (accessing)
 * it will often rej instead of returning false so you can see what went wrong
 * @param query what to search for
 * @param userID the uuid of the user
 * @returns a submission if it can find one, else a rejection with a reason
 */
export async function findOneAccess(query: mongoose.FilterQuery<{}>, userID: string): Promise<ISubmission> {

    return Submission.findOne(query)
        .then(submission => {
            return new Promise<ISubmission>(async (res, rej) => {
                if (!submission) {
                    rej(PermissionError.NoSuchUuid);
                }

                let canAccess: boolean = await checkPermsView(<any>submission, userID);
                if (!canAccess) {
                    rej(PermissionError.BadPermissions);
                }

                res((<ISubmission>submission))
            });

        })
}


/**
 * Wrapper function used to execute mongoose queries for getting a submission whilst checking permissions (edit)
 * it will often rej instead of returning false so you can see what went wrong
 * @param query what to search for
 * @param userID the uuid of the user
 * @returns a submission if it can find one, else a rejection with a reason
 */
export async function findOneEdit(query: mongoose.FilterQuery<{}>, userID: string): Promise<ISubmission> {

    return Submission.findOne(query)
        .then(submission => {
            return new Promise<ISubmission>(async (res, rej) => {
                if (!submission) {
                    rej(PermissionError.NoSuchUuid);
                }

                let canAccess: boolean = await checkPermsEdit(<any>submission, userID);
                if (!canAccess) {
                    rej(PermissionError.BadPermissions);
                }

                res((<ISubmission>submission))
            });

        })
}

/**
 * Special function used to change the state
 * Used a using a general updateOne was too cumbersome and wouldn't be used anywhere else
 * @param submissionUuid to change the state of
 * @param userID uuid of the user
 * @param newStage the proposed new state to change it to
 * @returns if a user can change a state
 */
export async function changeStage(submissionUuid: string, userID: string, newStage: SubmissionStages,): Promise<boolean> {

    // Issue here
    return await checkPermsChangeStageByUuid(submissionUuid, userID).then(async perms => {
        let canChange: boolean = false;

        switch (perms.stage) {
            case SubmissionStages.Unpublished:
                canChange = perms.canUnpublish;
                break;

            case SubmissionStages.Reviewing:
                canChange = perms.canReview;
                break;

            case SubmissionStages.Published:
                canChange = perms.canPublish;
                break;
        }

        if (!canChange) {
            return new Promise<boolean>((res, rej) => {
                rej(PermissionError.BadPermissions);
            });
        }
        return await Submission.updateOne({ uuid: submissionUuid }, { submissionStage: newStage });
    }).then(updatedSubmission => {
        return (updatedSubmission != undefined);
    }).catch(err => {
        return new Promise<boolean>((res, rej) => { res(true) })
    });
}

