import mongoose = require('mongoose');
import {IUser, UserSchema} from './Schema/user';
import config = require('../config.json');
import {logger} from "../Middleware/loggingMiddleware";

export const modelName = 'User';

function getUserConnection() {
    const conn = mongoose.createConnection(`mongodb://localhost:${config.databasePort}/user`, config.databaseCredentials);
    conn.model(modelName, UserSchema);

    conn.on('error', (err) => {
        logger.error(`Mongodb error on UserConnection: ${err} - exiting.`);
        process.exit(config.safeExitCode);
    });
    conn.on('disconnected', () => {
        logger.error(`UserConnection disconnected from Mongodb`);
    });
    conn.on('reconnected', () => {
        logger.info(`UserConnection reconnected to Mongodb!`)
    });
    return conn;
}

export function getUserModel(connection: mongoose.Connection): mongoose.Model<IUser, any, any, any> {
    return connection.model(modelName);
}

export const UserConnection = getUserConnection();