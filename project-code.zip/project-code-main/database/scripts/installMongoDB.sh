#!/bin/bash

linuxURL="https://fastdl.mongodb.org/linux/"
linuxFile="mongodb-linux-x86_64-rhel80-4.4.3"

macURL="https://fastdl.mongodb.org/osx/"
macFile="mongodb-macos-x86_64-5.0.3"

if [[ "$OSTYPE" == "linux-gnu"* ]]; then
  echo "Linux detected:"
  actualURL=$linuxURL
  actualFile=$linuxFile
elif [[ "$OSTYPE" == "darwin"* ]]; then
  echo "MacOS detected:"
  actualURL=$macURL
  actualFile=$macFile
else
  echo "Unsupported OS - Exiting."
  exit -1;
fi

actualSuffix=".tgz"

port=$(./getKey.py config.json databasePort 2>&1)

re='^[0-9]+$'
if ! [[ $port =~ $re ]] ; then
  echo "Invalid databasePort in config.json: $port"
  exit 1;
fi

password=$(./getKey.py config.json databasePassword 2>&1)
username=$(./getKey.py config.json databaseUsername 2>&1)

none="None"

if [ "$none" = "$password" ]; then
	echo "Invalid databasePassword in config.json"
	exit 1;
fi

if [ "$none" = "$username" ]; then
	echo "Invalid databaseUsername in config.json"
	exit 1;
fi

echo "Starting MongoDB installation:"

echo "Getting mongo package from ${actualURL}${actualFile}${actualSuffix}"

wget "${actualURL}${actualFile}${actualSuffix}"
tar xzvf "${actualFile}${actualSuffix}"
mv "${actualFile}" ~/mongodb
mkdir ~/mongodb_data
~/mongodb/bin/mongod --dbpath ~/mongodb_data --auth --port $port &

sleep 5s
~/mongodb/bin/mongo --port $port << EOF
use admin
var user = {
	"user":"$username",
	"pwd":"$password",
	roles: [{"role":"root","db":"admin"}]
}
db.createUser(user);
quit()
EOF

rm "${actualFile}${actualSuffix}"

sleep 1s

~/mongodb/bin/mongo --port $port -u $username --authenticationDatabase admin -p $password << EOF
use admin
db.shutdownServer()
quit()
EOF

echo "Finished MongoDB installation."

