#!/bin/bash

port=$(./getKey.py config.json databasePort 2>&1)

re='^[0-9]+$'
if ! [[ $port =~ $re ]] ; then
  echo "Invalid databasePort in config.json: $port"
  exit 1;
fi


password=$(./getKey.py config.json databasePassword 2>&1)
username=$(./getKey.py config.json databaseUsername 2>&1)

none="None"

if [ "$none" = "$password" ]; then
	echo "Invalid databasePassword in config.json"
	exit 1;
fi

if [ "$none" = "$username" ]; then
	echo "Invalid databaseUsername in config.json"
	exit 1;
fi



~/mongodb/bin/mongo --port $port -u $username -p $password --authenticationDatabase admin <<EOF
use admin
db.shutdownServer()
quit()
EOF
