#!/bin/bash
logpath="./logs"

port=$(./getKey.py config.json databasePort 2>&1)

re='^[0-9]+$'
if ! [[ $port =~ $re ]] ; then
  echo "Invalid databasePort in config.json: $port"
  exit 1;
fi

if [ ! -d "$logpath" ]; then
  echo "Creating log directory $logpath"
  mkdir "$logpath"
fi  

# Starts creates the database directory
if [ ! -d ~/mongodb_data ]; then
  echo "Creating database directory ~/mongodb_data"
  mkdir ~/mongodb_data
fi

# starts server
~/mongodb/bin/mongod --auth --port $port --dbpath ~/mongodb_data --logpath "$logpath/database" --fork;
