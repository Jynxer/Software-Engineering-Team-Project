import express = require('express');
import sanitize = require('mongo-sanitize');

import {logger} from '../Middleware/loggingMiddleware';
import { IStagePermissions, ISubmission } from '../interfaces/submissionInterface';
import { SubmissionStages } from './permission/submissionStages';
import { sendError } from '../interfaces/permissions';
import { changeStage, findOneAccess, checkPermsChangeStage } from '../database/permissionChecks/submission';

const router: express.Router = express.Router();

// Gets version of a submission
router.get('/submission/:uuid/version', (req, res) => {
    let submissionUuid:string = req.params.uuid;
    findOneAccess({uuid: submissionUuid}, res.locals.id).then(submission => {
        res.status(200).json({
            "status": "ok",
            "version": (<ISubmission>submission).versionNumber
        })
    }).catch(err => {
        sendError(err, 'submission - version', res, submissionUuid);
    })
});


// Used to change the stage of a submission
router.post('/submission/changeStage', (req, res) => {
    let submissionUuid: string = sanitize(req.body.submissionUuid);
    let newStage: SubmissionStages = sanitize(req.body.newStage);

    // Fetch the submission to see if we can access
    changeStage(submissionUuid, res.locals.id, newStage)
        .then(success => {
            if (success) {
                res.status(200).json({
                    "status": "ok",
                })
                logger.info(`Successfully change state of submission ${submissionUuid} to ${newStage}`)

                return;
            }

            logger.error("Managed to be able to change submission without actually being able actually change it")
            res.status(500).json({
                "status": "error",
                "message": "Internal server error"
            })
            return;
        }).catch(err => {
            sendError(err, 'submission', res, `submission: ${submissionUuid}, newStage: ${newStage}`);
        })
});

// Gets the submission stage of the given submisison - used to show different content to user
router.get('/submission/:uuid/getStage', (req, res) => {
    let submissionUuid: string = sanitize(req.params.uuid);
    let authorUuid: string = sanitize(res.locals.id);

    // Fetch the submission to see if we can access
    findOneAccess({ uuid: submissionUuid }, authorUuid).then(async submission => {

        // Summary of the stage of the submission and what the user can do
        let body: IStagePermissions = await checkPermsChangeStage(submission, authorUuid);

        res.status(200).json({
            "status": "ok",
            "stage": body
        })
    }).catch(err => {
        sendError(err, 'submission - get stage', res, submissionUuid);
    })
});

export const main = router;
