import express = require('express');
import {getUserModel, UserConnection} from '../../database/userdb';
import {logger} from "../../Middleware/loggingMiddleware";
import {IUser} from "../../database/Schema/user";
import {roleToInt, userHasPermissions} from "./permissionUtils";
import {Role} from "./roles";

const router: express.Router = express.Router();

const User = getUserModel(UserConnection);

//Interfaces

export interface Modify {
    uuid: string;
    role: Role;
}

export interface Has {
    uuid?: string;
    role: Role[];
}

export interface Get {
    uuid?: string;
}


//Routes

router.get('/numeric/:role', (req, res) => {

    try {
        const role : Role = <Role> req.params.role;
        res.status(200).json({
            status: "ok",
            value: roleToInt(role)
        })
        return;
    } catch (err: any) {
        res.status(400).json({
            status: "error",
            message: "malformed request"
        })
    }
})

router.post('/get', async (req, res) => {
    if (res.locals.authorised) {
        if (!res.locals.id) {
            res.status(400).json({status: "error", message: "not logged in"});
            logger.error(`IP ${req.ip} made an authentication check request with a valid token, but no id!`);
            return;
        }

        try {
            const reqInfo : Get = req.body
            let queryUuid = res.locals.id;

            if (reqInfo.uuid) {
                if (await userHasPermissions(res.locals.id, [Role.Admin]).catch((err) => {
                    logger.error(`Error finding user ${res.locals.id}: ${err}`)
                    res.status(500).json({status: "error", message: "internal server error"})
                    return
                })) {
                    queryUuid = reqInfo.uuid;
                } else {
                    logger.warn(`ID: ${res.locals.id} does not have permission to view other user's permission level.`)
                    res.status(403).json({status: "error", message: "invalid permission"})
                    return
                }
            }

            try {
                const user: IUser = await User.findOne({uuid: queryUuid}).catch((err: any) => {
                    logger.error(`Error when attempting to find user ${queryUuid}: ${err}`)
                    res.status(500).json({status: "error", message: "internal server error"})
                    return
                })
                res.status(200).json({status: "ok", role: user.role})

            } catch (err) {
                logger.warn(`Could not find uid ${queryUuid}: ${err}`)
                res.status(400).json({status: "error", message: "invalid uuid"})
                return
            }

        } catch (err) {
            logger.warn(`IP: ${req.ip} made a request to get permissions with invalid syntax.`)
            res.status(400).json({
                status: "error",
                message: "badly formed request"
            });
            return
        }

    } else {
        res.status(401).json({
            status: "error",
            message: "not logged in"
        })
        return
    }
})

router.post('/has', async (req, res) => {

    if (res.locals.authorised) {
        if (!res.locals.id) {
            res.status(400).json({status: "error", message: "not logged in"});
            logger.error(`IP ${req.ip} made an authentication check request with a valid token, but no id!`);
            return;
        }

        try {
            const reqInfo : Has = req.body
            let queryUuid = res.locals.id;

            if (reqInfo.uuid) {
                if (await userHasPermissions(res.locals.id, [Role.Admin]).catch((err) => {
                    logger.error(`Error finding user ${res.locals.id}: ${err}`)
                    res.status(500).json({status: "error", message: "internal server error"})
                    return
                })) {
                    queryUuid = reqInfo.uuid;
                } else {
                    logger.warn(`ID: ${res.locals.id} does not have permission to view other user's permission level.`)
                    res.status(403).json({status: "error", message: "invalid permission"})
                    return
                }
            }

            const check = await userHasPermissions(queryUuid, reqInfo.role).catch((err) => {
                logger.warn(`ID: ${res.locals.id} made a check for permissions which could not be found: ${err}`)
                res.status(400).json({status: "error", message: "badly formed request"})
                return
            })

            res.status(200).json({status: "ok", has: `${check}`})
            return

        } catch (err) {
            logger.warn(`IP: ${req.ip} made a request to check permission with invalid syntax.`)
            res.status(400).json({
                status: "error",
                message: "badly formed request"
            });
            return
        }

    } else {
        res.status(401).json({
            status: "error",
            message: "not logged in"
        })
        return
    }

})

router.post('/update', async (req, res) => {
    if (res.locals.authorised) {
        if (!res.locals.id) {
            res.status(400).json({status: "error", message: "not logged in"});
            logger.error(`IP ${req.ip} made an authentication check request with a valid token, but no id!`);
            return;
        }
        try {
            const reqInfo: Modify = req.body;
            const requestedRole = reqInfo.role
            const requesterPromise: Promise<IUser> = User.findOne({uuid: res.locals.id})
            const subjectPromise: Promise<IUser> = User.findOne({uuid: reqInfo.uuid})

            try {
                const requester = await requesterPromise.catch(err => {
                    logger.warn(`Could not find requester ${res.locals.id} on update call: ${err}`);
                    throw err
                })

                const subject = await subjectPromise.catch(err => {
                    logger.warn(`Could not find subject ${reqInfo.uuid} on update call: ${err}`);
                    throw err
                })

                const requesterPermissionLevel = roleToInt(requester.role);
                const requestedPermissionChange = roleToInt(requestedRole);

                if (requestedPermissionChange <= requesterPermissionLevel) {
                    if (requestedPermissionChange < requesterPermissionLevel) {
                        logger.warn(`Could not change permission, ${requester.username} does not have the ${reqInfo.role} permission.`);
                    } else {
                        logger.warn(`Could not change permission, cannot promote to the same role.`);
                    }
                    res.status(401).json({
                        status: "error",
                        message: "unauthorised"
                    });
                    return
                }

                const subjectPermissionLevel = roleToInt(subject.role);

                if (subjectPermissionLevel <= requesterPermissionLevel) {
                    if (subjectPermissionLevel == requesterPermissionLevel) {
                        logger.warn(`Could not change permission: users have the same permissions`);
                    } else {
                        logger.warn(`Could not change permission: user has higher permissions`);
                    }
                    res.status(401).json({
                        status: "error",
                        message: "unauthorised"
                    });
                    return
                }

                if (requestedRole == Role.Banned && requesterPermissionLevel > roleToInt(Role.Editor)){
                    logger.warn(`Could not change permission: user does not have permission to ban.`);
                    res.status(401).json({
                        status: "error",
                        message: "unauthorised"
                    });
                    return;
                }

                if (requestedRole == Role.Mute && requesterPermissionLevel > roleToInt(Role.Reviewer)){
                    logger.warn(`Could not change permission: user does not have permission to mute.`);
                    res.status(401).json({
                        status: "error",
                        message: "unauthorised"
                    });
                    return;
                }

                subject.role = requestedRole;

                await subject.save().then(() => {
                    logger.info(`${requester.username} changed ${subject.username}'s role to '${subject.role}'`);
                    res.status(200).json({
                        status: "ok"
                    });
                    return
                }).catch(err => {
                    logger.error(`Could not change permission of ${subject.username}: ${err}`);
                    res.status(500).json({
                        status: "error",
                        message: "internal server error"
                    })
                    return
                })

            } catch (err) {
                res.status(400).json({
                    status: "error",
                    message: "could not find user"
                });
                return
            }

        } catch (err) {
            logger.warn(`IP: ${req.ip} made a request to update permission with invalid syntax.`)
            res.status(400).json({
                status: "error",
                message: "badly formed request"
            });
            return
        }
    } else {
        res.status(401).json({
            status: "error",
            message: "not logged in"
        })
        return
    }
});

export const permission = router;
