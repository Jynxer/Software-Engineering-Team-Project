export enum Role {
    Admin = 'Admin',
    Editor = 'Editor',
    Reviewer = 'Reviewer',
    Author = 'Author',
    Viewer = 'Viewer',
    Mute = 'Mute',
    Banned = 'Banned'
}