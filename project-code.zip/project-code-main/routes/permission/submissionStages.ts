export enum SubmissionStages {
    Unpublished = 'Unpublished',
    Reviewing = 'Reviewing',
    Published = 'Published'
}