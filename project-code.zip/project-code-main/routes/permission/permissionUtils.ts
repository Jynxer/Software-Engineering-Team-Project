import {Role} from "./roles";
import {IUser} from "../../database/Schema/user";
import {getUserModel, UserConnection} from '../../database/userdb';

const User = getUserModel(UserConnection);

/**
 * Checks if the given uuid has the given permission
 *
 * @param uuid : string representing a user's uuid
 * @param permission : Role[] the permissions to check.
 */
export function userHasPermissions(uuid: string, permission: Role[]): Promise<boolean> {
    return new Promise<boolean>(async (res, rej) => {
        try {
            const user: IUser = await User.findOne({uuid: uuid});
            res(permission.every((role: Role) => hasPermission(user, role)));
        } catch (err) {
            rej(err)
        }
    })
}

/**
 * Checks if the given IUser has the requisite permission level
 *
 * @param user : IUser to check
 * @param permission : Role to check `user` has
 */
function hasPermission(user: IUser, permission: Role): boolean {
    return roleToInt(user.role) <= roleToInt(permission);
}

/**
 * Assigns a numerical value to a given role. The lower the value, the higher the permission level.
 *
 * <p>
 *     On unknown permissions, returns the highest possible number.
 * </p>
 *
 * @param role : Role to decode
 * @return number
 */
export function roleToInt(role: Role): number {
    switch (role) {
        case Role.Admin:
            return 0
        case Role.Editor:
            return 10
        case Role.Reviewer:
            return 20
        case Role.Author:
            return 30
        case Role.Viewer:
            return 40
        case Role.Mute:
            return 50
        default:
            return 100
    }
}
