import express = require('express');
import sanitize = require('mongo-sanitize');

import { getUserModel, UserConnection } from '../../database/userdb';
import { getAuthModel, AuthConnection } from '../../database/authdb';

import { logger } from '../../Middleware/loggingMiddleware';
import { ISGUser } from '../../interfaces/userInterface';
import { IUser } from '../../database/Schema/user';
import { IAuth } from '../../database/Schema/auth';
import { userHasPermissions } from '../permission/permissionUtils';
import { Role } from '../permission/roles';

const router: express.Router = express.Router();

const User = getUserModel(UserConnection);
const Auth = getAuthModel(AuthConnection);

interface password {
    old: string,
    new: string,
    uuid?: string
}

router.post('/auth', async (req, res) => {
    if (res.locals.authorised) {
        if (!res.locals.id) {
            res.status(400).json({ status: "error", message: "Not logged in." });
            logger.error(`IP ${req.ip} made an authentication check request with a valid token, but no id!`);
            return;
        }
        try {
            const body: password = req.body;
            let uid: string;
            let isAdmin = false;

            if (body.uuid) {
                if (await userHasPermissions(res.locals.id, [Role.Admin])
                    .catch((err: any) => {
                        logger.error(`Could not check for user permissions: ${err.message}`)
                        res.status(500).json({
                            status: "error",
                            message: "internal server error"
                        })
                        return;
                    })) {
                    uid = body.uuid;
                    isAdmin = true;
                } else {
                    logger.warn(`User ${res.locals.id} attempted to change the password of another user without the requisite permission.`);
                    res.status(401).json({
                        status: "error",
                        message: "unauthorised"
                    })
                    return;
                }
            } else {
                uid = res.locals.id;
            }

            try {
                let user: any = <IAuth>await Auth.findOne({ uuid: uid });

                if (!isAdmin) {
                    user.comparePassword(body.old, async function (err: any, match: any) {
                        if (err || !match) {
                            if (err) {
                                logger.error(`Error checking password for IP '${req.ip}' when attempting to change passwords'.`);
                                res.status(500).json({
                                    status: "error",
                                    message: "internal server error"
                                })
                                return;
                            } else {
                                logger.warn(`IP '${req.ip}' made an unauthorised password change request for ${uid}`);
                                res.status(401).json({
                                    status: "error",
                                    message: "unathorised"
                                });
                                return;
                            }
                        }

                        user.password = body.new;

                        try {
                            await user.save()
                            logger.info(`Changed password for user ${user.username}`);
                            res.status(200).json({
                                status: "ok"
                            })
                            return;
                        } catch (err: any) {
                            logger.error(`Could not change password for user ${user.username}: ${err.message}`)
                            res.status(500).json({
                                status: "error",
                                message: "internal server error"
                            })
                            return;
                        }
                    })
                }


            } catch (err: any) {
                logger.warn(`Could not find user with uuid ${uid}: ${err.message}`);
                res.status(400).json({
                    status: "error",
                    message: "could not find user"
                })
            }
        } catch (err: any) {
            logger.warn(`${res.locals.id} made a malformed request to change a password.`)
        }
    } else {
        res.status(400).json({ status: "error", message: "Not logged in." })
        logger.warn(`IP ${req.ip} made a request for a username without being logged in.`);
    }
})


router.post('/user', (req, res) => {
    if (res.locals.authorised) {
        if (!res.locals.id) {
            res.status(400).json({ status: "error", message: "Not logged in." });
            logger.error(`IP ${req.ip} made an authentication check request with a valid token, but no id!`);
            return;
        }
        try {
            const user: ISGUser = req.body;

            userHasPermissions(res.locals.id, [Role.Reviewer])
                .then((has: boolean) => {
                    if (has) {
                        updateUserInfo(user, true)
                            .then((success: boolean) => {
                                if (success) {
                                    res.status(200).json({
                                        status: "ok"
                                    })
                                    return;
                                } else {
                                    res.status(500).json({
                                        status: "error",
                                        message: "internal server error"
                                    })
                                    return;
                                }
                            })
                            .catch((_: any) => {
                                res.status(500).json({
                                    status: "error",
                                    message: "internal server error"
                                })
                                return;
                            })
                    } else {
                        if (res.locals.id == user.uuid) {
                            updateUserInfo(user, false)
                                .then((success: boolean) => {
                                    if (success) {
                                        res.status(200).json({
                                            status: "ok"
                                        })
                                        return;
                                    } else {
                                        res.status(500).json({
                                            status: "error",
                                            message: "internal server error"
                                        })
                                        return;
                                    }
                                })
                                .catch((_: any) => {
                                    res.status(500).json({
                                        status: "error",
                                        message: "internal server error"
                                    })
                                    return
                                })
                        } else {
                            logger.warn(`User: ${res.locals.id} does not have the permission to alter the details of other users`)
                            res.status(401).json({
                                status: "error",
                                message: "unauthorised"
                            })
                            return;
                        }
                    }
                })
                .catch((err: any) => {
                    logger.error(`Could not find user with uuid ${res.locals.id}: ${err}`)
                    res.status(500).json({
                        status: "error",
                        message: "internal server error"
                    })
                    return;
                });

        } catch (err) {
            logger.warn(`${res.locals.id} made a malformed request to change their details.`)
            res.status(400).json({
                status: "error",
                message: "malformed request"
            })
            return;
        }
    } else {
        res.status(400).json({ status: "error", message: "Not logged in." })
        logger.warn(`IP ${req.ip} made a request for a username without being logged in.`);
    }
})

async function updateUserInfo(details: ISGUser, isAdmin: boolean): Promise<boolean> {
    try {
        const user: IUser = await User.findOne({ uuid: details.uuid })
        Object.keys(details).forEach(key => {
            switch (key) {
                case 'username':
                    user.username = sanitize(details.username);
                    break;
                case 'fullName':
                    user.fullName = sanitize(details.fullName);
                    break;
                case 'journalId':
                    if (isAdmin) {
                        user.journalId = sanitize(details.journalId);
                    }
                    break;
                case 'profilePicUrl':
                    user.profilePicture = sanitize(details.profilePicUrl);
                    break;
                default:
            }
        });
        await user.save()
        return true;
    } catch (err) {
        logger.error(`Error when updating user: ${err}`)
        return false;
    }
}

export const editDetails = router;
