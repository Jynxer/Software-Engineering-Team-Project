import express = require('express');

// import routes
import { main } from './main';
import { upload } from './upload';
import { comments } from './comments'
import { sg } from './supergroup';
import { registerLogout } from './login/login';
import { permission } from "./permission/permissionEndpoints";
import { editDetails } from './details/details';

const router: express.Router = express.Router();

router.use('/', main);
router.use('/', upload);
router.use('/', comments);
router.use('/v1', sg);
router.use('/', registerLogout);
router.use('/permissions', permission);
router.use('/modify', editDetails);

// Redirect all //v1 to /v1 as we may have multiple // in the url (as one group didn't add it at the end of the url)
// so we can't assume all end with /
router.get('//v1/:path(*)', (req, res) => {
    res.redirect(`/v1/${req.params.path}`);
})

export const routes = router;
