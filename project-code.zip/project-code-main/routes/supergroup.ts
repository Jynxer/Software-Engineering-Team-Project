import request = require('request');
import express = require('express');

import sanitize = require("mongo-sanitize");
import { v4 as uuidv4 } from 'uuid';
import { Request, Response, NextFunction } from 'express';
import stream = require('stream');


//routes
import { submissions } from './supergroup/submissions';
import { comments } from './supergroup/comments';
import { users } from './supergroup/users';
import { login } from './login/login'
import SuperGroupUrls = require('./supergroup.json');
//middleware
import { logger } from '../Middleware/loggingMiddleware';

//file handling
import content = require('../database/filedb');
import { uploadFiles } from '../database/filesystem';

//interfaces
import { IFileContent } from '../interfaces/fileInterface';

const Submission = content.getSubmissionModel(content.contentConnection);
const File = content.getFileModel(content.contentConnection);
const router: express.Router = express.Router();

function getID(req: Request, res: Response, next: NextFunction) {
    let id: string = req.query.id ? <string>req.query.id : "7";

    if (id !== "7") {

        let supergroup = Object(SuperGroupUrls)[id];

        if (!supergroup) {
            res.status(400).json({
                "status": "error",
                "message": "invalid super group id"
            })
            return;
        }
        let url: string = `${supergroup.url}${req.baseUrl}${req.url}`;

        //https://stackoverflow.com/questions/24381480/remove-duplicate-forward-slashes-from-the-url#24381515
        url = url.replace(/([^:]\/)\/+/g, "$1");

        request(url, (err, response, body) => {
            if (err) {
                logger.warn(`Failed to get data from ${id}, ${url}: ${err} `)

                res.status(500).json({
                    "status": "error",
                    "message": "error when getting data from server"
                })
                return;
            }

            try {
                res.set(response.headers)
                let data = JSON.parse(body);
                res.status(response.statusCode).json(data);
            } catch (e) {
                logger.warn(`Failed to parse data from ${id}, ${url}: ${e} `)
                res.status(500).json({
                    "status": "error",
                    "message": "Internal server error"
                })
            }
        })

    } else {
        next();
    }
}


router.use(getID)
router.use('/users', users);
router.use('/submissions', submissions);
router.use('/comments', comments);
router.use('/', login);


// Need to change to get zip file instead - should be easy fix
router.get('/migrate/:journalId/:submissionUuid', (req, res) => {
    if (!res.locals.authorised) {
        res.json({
            status: "error",
            message: "Not logged in"
        });
        logger.warn(`IP ${req.ip} is not logged in`);
        return;
    } else if (!res.locals.id) {
        logger.error(`IP ${req.ip} is authenticated, but has no uuid!`);
        res.status(400).json({
            status: "error",
            message: "Not logged in"
        })
        return;
    }

    // Gets required information from request
    let submissionUuid = req.params.submissionUuid;
    let journalId: string = req.params.journalId;
    let supergroup = Object(SuperGroupUrls)[journalId];


    if (!supergroup) {
        res.json({
            status: "error",
            message: "No such journal"
        });
        return;
    }

    let url: string = `${supergroup.url}/v1/submissions/${submissionUuid}`.replace(/([^:]\/)\/+/g, "$1");

    // Sets the url to the get the submission   

    request(url, function (error, response, body) {
        // If there was an error or no body to the message
        if (error || !body) {
            res.json({
                status: "error",
                message: "Failed to reach other journal"
            });
            logger.warn(`Failed to reach journal ${journalId}.`);
            return;
        }

        let resJSON;
        try {
            resJSON = JSON.parse(body);
        }
        catch (e) {
            logger.debug('Failed to get data from sg' + e);
            res.status(502).json({
                'status': 'error',
                'message': 'Bad response from server'
            })
            return;
        }
        // If the the journal couldn't find the submission
        if (resJSON.status !== 'ok') {
            res.json({
                status: "error",
                message: `Failed to get submission: ${sanitize(resJSON.message)}`
            });
            logger.warn(`Failed to get submission ${sanitize(resJSON.message)}`);
            return;
        }

        let newSubmissionUuid: string = uuidv4();

        let newSubmission = new Submission({
            uuid: newSubmissionUuid,
            kind: 'repost',
            authorUuid: res.locals.id,
            title: sanitize(resJSON.submission.title),
            description: sanitize(resJSON.submission.description),
            submissionDate: Date.now(),
            originalUuid: submissionUuid,
            originalJournalId: journalId,
        });

        let chunks: any = [];
        let data: stream = request(url + '/contents?download',);
        data.on('data', (chunk) => chunks.push(chunk));
        data.on('end', () => {
            let newBuf: Buffer = Buffer.concat(chunks);
            let zipFile: IFileContent = {
                name: 'migration.zip',
                contents: newBuf
            }

            uploadFiles([zipFile], newSubmissionUuid, 1)
                .then(files => File.insertMany(files))
                .then(() => newSubmission.save())
                .then(() => res.status(200).json({
                    status: "ok",
                    uuid: newSubmissionUuid,
                }))
                .catch(async err => {

                    await Submission.findOneAndDelete({ uuid: submissionUuid });
                    res.status(500).json({
                        status: "error",
                        message: "Server error"
                    });
                    logger.error(`Failed to migrate from journal ${journalId}: ${err}`);
                    logger.debug(err);
                })
        });
    });
});

router.get('/download/:journalId/:submissionUuid', (req, res) => {
    let id = req.params.journalId
    let uuid: string = sanitize(req.params.submissionUuid);
    if (id == '7') {
        res.redirect(`/v1/submissions/${uuid}/contents?download`);
        return;
    }
    let supergroup = Object(SuperGroupUrls)[id];
    if (!supergroup) {
        res.json({
            status: "error",
            message: "No such journal"
        });
        return;
    }

    let url = `${supergroup.url}/v1/submissions/${uuid}/contents?download`
    url = url.replace(/([^:]\/)\/+/g, "$1");
    request(url).pipe(res);
});


export const sg = router;
