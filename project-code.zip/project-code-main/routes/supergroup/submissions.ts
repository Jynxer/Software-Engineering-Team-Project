import express = require('express');
import sanitize = require('mongo-sanitize');
import yazl = require('yazl');

import content = require('../../database/filedb');


import { findManyAccess, findOneAccess } from '../../database/permissionChecks/submission';
import { ISGComment } from '../../interfaces/commentInterface';
import { CommentStages } from '../../interfaces/commentInterface'

import { sendError } from '../../interfaces/permissions';
import { getCommentStage } from '../../database/permissionChecks/comment';
import { SubmissionStages } from '../../routes/permission/submissionStages';

const File = content.getFileModel(content.contentConnection);
const Comment = content.getCommentModel(content.contentConnection);

const router: express.Router = express.Router();

// Finds as  many submissions as listed which user can access
router.get('/latest', (req, res) => {
    // Sets default for each query to right most value if it isn't present
    let skip: number = req.query.skip ? +req.query.skip : 0;
    let startDate: Date = req.query.startDate ? sanitize(new Date(req.query.startDate.toString())) : new Date(0);
    let take: number = req.query.take ? +req.query.take : 0;
    findManyAccess({submissionDate: { $gte: startDate } }, res.locals.id, skip, take, {
        submissionDate: -1
    }).then((submissions) => {
        res.status(200).json({
            status: "ok",
            total: submissions.length,
            submissions: submissions
        });

    }).catch(err => {
        sendError(err, 'latest submissions', res);
        return;
    })
});

// Find one submisison to access
router.get('/:uuid', (req, res) => {
    let submissionUuid: string = sanitize(req.params.uuid);
    findOneAccess({uuid: submissionUuid}, res.locals.id )
    .then(submission => {
        res.status(200).json({
            status: "ok",
            submission: (<any>submission).format()
        });
    }).catch(err => {
        sendError(err, 'submission', res, submissionUuid);
    });
});

// Fetches the file based on the path
router.get('/:uuid/comments/:path(*)', async (req, res) => {
    let submissionUuid: string = sanitize(req.params.uuid);
    let pathStr: string = '/' + sanitize(req.params.path);
    let version: number | null = req.query.version ? Number(sanitize(req.query.version)) : null
    // Finds the find for the submission with the given path, submisison uuid and the found version number

    // We first find the submission to get its stage
    findOneAccess({uuid: submissionUuid}, res.locals.id)
    .then(async submission => {

        // If no file exists
        if(!await File.exists({ submissionUuid: submissionUuid, path: pathStr, versionNumber: version })) {
            res.json(404).json({
                "status":"error",
                "message": "File not found"
            });
            return;
        }

        let stage: CommentStages | null = getCommentStage(<SubmissionStages>submission.submissionStage);
        if (!stage) {
            res.json(400).json({
                "status":"error",
                "message": "Can't comment on unpublished submission"
            });
            return;
        }

        // Sets the version to the submissions version if it is not provided in query
        if (!version) {
            version = submission.versionNumber;
        }

        
        // Default with no parameters is 0 meaning it would get all available
        let limit: number = req.query.take ? +req.query.take : 0;
        let skip: number = req.query.skip ? +req.query.skip : 0;

        // Finds comments attached to a post
        Comment.find({ submissionUuid: submissionUuid, path: pathStr, stage: stage })
            .skip(skip)
            .limit(limit)
            .then((comments: any[]) => {
                let SGComments: ISGComment[] = comments.map((comment) => { return comment.formatSG() });
                res.json({
                    "status": "ok",
                    "total": SGComments.length,
                    "comments": SGComments
                })
            })
    }).catch(err => {
        sendError(err, 'file', res, `path: ${pathStr}, submission:${submissionUuid}`)
    })
});


// Fetches the file based on the path
router.get('/:uuid/contents/:path(*)', async (req, res) => {
    let submissionUuid: string = sanitize(req.params.uuid);
    let userID:string =  sanitize(res.locals.id);
    let pathStr: string = '/' + sanitize(req.params.path);
    let version: number | null = req.query.version ? Number(sanitize(req.query.version)) : null
    // Finds the find for the submission with the given path, submisison uuid and the found version number
    

    // Finds the find for the submission
    findOneAccess({ uuid: submissionUuid}, userID)
    .then(async submission => {
        if (!version) {
            // Gets latest version if submission isn't set
            version = submission.versionNumber;
        }
        return <any>File.findOne({submissionUuid: submissionUuid, path: pathStr, versionNumber: version})
     })
    .then(file => {
        if (!file) {
            res.status(404).json({
               "status":"error",
               "message": "File not found"
            });
            return;
        }
        if (file.isFile) {
            res.status(200).json({
                "status":"ok",
                "submissionPathContents":{ 
                   "type": "file",
                    "filename": file.fileName,
                    "contents": file.content
                }
            });
            return;
        }
        // Regex which matches the parent dir, then at least one character and potentially a final /
        // Only matches entries which have the parent file as a parent in their path
        let childRegex:RegExp = new RegExp(`^${file.path}([^/])+(/)?$`);

        // Gets the child files of for the file
        File.find({ path: { $regex: childRegex}, submissionUuid: submissionUuid, versionNumber: version}).then((files: any) => {
            let dirEntries: any[] = files.map((childFile: any) => {
                return {
                    type: childFile.isFile ? "file" : "directory",
                    filename: childFile.fileName, 
                }
            
            });
            res.status(200).json({
                "status":"ok",
                "submissionPathContents": {
                    "type": "directory",
                    "filename": file.fileName,
                    "entries": dirEntries
                }
            })
        })
    
    }).catch(err => {
        sendError(err, 'file', res, `path: ${pathStr}, submission:${submissionUuid}`);
    })
});


// Fetches a zip file asasociated with the submission
// Matches - /v1/submissions/{uuid}/contents?download 
router.get('/:uuid/contents', async (req, res, next) => {
    // Checks if it is followed by a ?download - ugly hack but good for now
    if (!('download' in req.query)) {
        next();
        return;
    }

    // Gets the submission info
    let submissionUuid: string = sanitize(req.params.uuid);
    let userID:string = sanitize(res.locals.id);
    let version: number | null = req.query.version ? Number(sanitize(req.query.version)) : null


    // Gets all files with directories first
    // Finds the find for the submission with the given path, submisison uuid and the found version number
    findOneAccess({uuid: submissionUuid}, userID)
    .then(submission => {
        if (!version) {
            version = submission.versionNumber;
        }
        File.find({ submissionUuid: submissionUuid, versionNumber: version})
         .sort({
             isFile: 1
         })
        .then((files: any) => {
            if (!files) {
                res.json({
                    "status": "error",
                    "message": "No files found"
                });
                return;
            }
            // Creates new zip file
            let zipfile = new yazl.ZipFile();
            // Sets necessary headers - may need to set length too
            res.set({
                "Content-Type": "application/zip",
                "Content-Disposition": `attachment; filename=${submission.title}.zip`,
            });

            const options: Partial<yazl.DirectoryOptions> & yazl.EndOptions = {
                forceZip64Format: false
            }

            // Pipes the files to res
            let zipPipe = zipfile.outputStream;
            zipPipe.pipe(res);
            zipPipe.on('end', () => {
                // Send on completion
                res.status(200);
            })

        
            // Loops through each file, adding it to the zipfile
            for (let file of files) {
                // Replaces one leading / to make it work with yazl
                let filePath: string = file.path.replace(/^\//, '');

                // If not path (root dir) or the file is a dir we skip
                if (!filePath || !file.isFile) {
                    continue;
                }

                // Creates a zip file with the content - remove start / from path
                zipfile.addBuffer(Buffer.from(file.content), filePath);
            }
            zipfile.end(options);

        })
    }).catch(err => {
        sendError(err, 'zipping file', res, submissionUuid);
    });
});


export const submissions = router;
