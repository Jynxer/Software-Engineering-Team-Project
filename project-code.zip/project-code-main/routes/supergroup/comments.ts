// Comment related endpoints for the supergroup
import express = require('express');
import sanitize = require('mongo-sanitize');
import { logger } from '../../Middleware/loggingMiddleware'
import { commentFindOne } from '../../database/permissionChecks/comment';
import { sendError } from '../../interfaces/permissions'
const router: express.Router = express.Router();

router.get('/:uuid', (req, res) => {
    // Gets a comment by its uuid
    let commentUuid:string = sanitize(req.params.uuid);
    // We don't care about stage or version as this is by uuid
    commentFindOne({uuid: commentUuid, resolved: false}, res.locals.id)
    .then(async comment => {
            res.status(200).json({
                status: "ok",
                comment: (<any>comment).formatSG()
            });
            logger.debug(`Success!`);
    }).catch(err => {
        sendError(err, 'file', res, commentUuid);
    })
    
});

export const comments = router;
