import express = require('express');
import sanitize = require('mongo-sanitize');

import { getUserModel, UserConnection } from '../../database/userdb';
import { logger } from '../../Middleware/loggingMiddleware';
import { ISGSubmission } from '../../interfaces/submissionInterface'
import content = require('../../database/filedb');

const router: express.Router = express.Router();

const User = getUserModel(UserConnection);
const Submission = content.getSubmissionModel(content.contentConnection);

router.get('/:uuid', (req, res) => {
    // Finds user based on given uuid
    User.findOne({ uuid: sanitize(req.params.uuid) })
        .exec(function (err: any, user: any) {
            if (err) {
                res.status(500).json({
                    status: "error",
                    message: "Internal server error"
                });
                logger.error(`Error occurred while searching for uuid ${sanitize(req.params.uuid)}`);
                logger.debug(err);
                return;
            }

            if (!user) {
                res.status(400).json({
                    status: "error",
                    message: 'No user uuid found'
                });
                logger.warn(`No user with uuid ${sanitize(req.params.uuid)} found`);
                return;
            }

            res.status(200).json({
                status: "ok",
                user: user.format()
            });
            logger.debug("Success!");
        });
});

router.get("/search/:query", (req, res) => {
    try {
        const query = sanitize(req.params.query);
        const type = req.query.type;
        let limit: number = Math.floor(Number(req.query.limit));

        if (limit > 100) {
            limit = 100;
        }
        if (limit < 1) {
            limit = 1;
        }

        let filter = {}
        let queryRegex = new RegExp(`.*${query}.*`);
        switch (type) {
            case "name":
                filter = { username: { $regex: queryRegex, $options: 'i' } };
                break;
            case "uuid":
                filter = { uuid: { $regex: queryRegex, $options: 'i' } };
                break;
            default:
                res.status(400).json({
                    status: "error",
                    message: "search type not supported"
                })
        }
        User.find(filter).limit(limit)
            .then((users: any[]) => {

                const list: any[] = [];
                for (let i = 0; i < users.length; i++) {
                    let role = users[i].role
                    users[i] = users[i].format()
                    users[i]['role'] = role
                    list.push(users[i]);
                }

                res.status(200).json({
                    status: "ok",
                    users: list
                })
                return
            })
            .catch((err: any) => {
                logger.warn(`Error occured when searching for ${type} with ${query}: ${err}`);
                res.status(400).json({
                    status: "error",
                    message: "nothing found"
                })
            })
    } catch (err: any) {
        res.status(400).json({
            status: "error",
            message: "badly formed request"
        })
    }
})


router.get('/:uuid/submissions', (req, res) => {
    // Default with no parameters is 0 meaning it would get all available
    let limit: number = req.query.take ? +req.query.take : 0;
    let skip: number = req.query.skip ? +req.query.skip : 0;

    // Gets the submissions for a given user
    Submission.find({ authorUuid: sanitize(req.params.uuid) })
        .skip(skip)
        .limit(limit)
        .exec(function (err: any, submissions: any) {
            if (err) {
                res.status(500).json({
                    status: "error",
                    message: "Internal server error"
                });
                logger.error(`Error occurred while searching for uuid ${sanitize(req.params.uuid)}`);
                logger.debug(err);
                return;
            }

            if (!submissions) {
                res.status(400).json({
                    status: "error",
                    message: 'Author uuid not found'
                });
                logger.warn(`No author with uuid ${sanitize(req.params.uuid)} found`);
                return;
            }

            let submissionList: ISGSubmission[] = submissions.map((submission: any) => { return submission.format() })

            res.status(200).json({
                status: "ok",
                submissions: submissionList
            });
            logger.debug("Success!");
        });
});

export const users = router;
