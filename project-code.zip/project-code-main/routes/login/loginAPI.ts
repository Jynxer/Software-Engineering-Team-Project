import express = require('express');
import sanitize = require('mongo-sanitize');

import { getUserModel, UserConnection } from '../../database/userdb';
import { getAuthModel, AuthConnection } from '../../database/authdb';

import { logger } from '../../Middleware/loggingMiddleware';

const router: express.Router = express.Router();

const User = getUserModel(UserConnection);
const Auth = getAuthModel(AuthConnection);

router.get('/user', async (req, res) => {
    if (res.locals.authorised) {
        if (res.locals.id) {
            logger.debug(`UserID ${res.locals.id} is authenticated - returning uid: ${res.locals.id}`);
            res.status(200).json({ uid: res.locals.id, status: "ok" });
            return;
        }
        res.status(400).json({ status: "error", message: "Not logged in." });
        logger.error(`IP ${req.ip} made an authentication check request with a valid token, but no id!`);
        return;
    }
    res.status(400).json({ status: "error", message: "Not logged in." });
    logger.debug(`IP ${req.ip} is not authenticated`);
});

router.get('/getUsername', async (req, res) => {
    if (res.locals.authorised) {
        if (!res.locals.id) {
            res.status(400).json({ status: "error", message: "Not logged in." });
            logger.error(`IP ${req.ip} made an authentication check request with a valid token, but no id!`);
            return;
        }
        logger.debug(`Getting username for ${res.locals.id}:`)
        User.findOne({ uuid: sanitize(res.locals.id) }, function (err: any, user: any) {
            // Failed to find user
            if (err) {
                res.status(500).json({ status: "error", message: "server error" });
                logger.error(`Mongodb error : ${err}`);
                return;
            }
            if (!user || !user.username) {
                res.status(400).json({ status: "error", message: "No username." });
                logger.error(`IP ${req.ip} made a username check request for an invalid uid.`);
                return;
            }

            // Checks passwords - return pfp as well as makes it easier to display
            res.status(200).json({ status: "ok", username: user.username, pfp: user.profilePicture });
            logger.debug(`Username: ${user.username} found!`);
            return;
        });
    } else {
        res.status(400).json({ status: "error", message: "Not logged in." })
        logger.warn(`IP ${req.ip} made a request for a username without being logged in.`);
    }
});

router.get('/getAuthname', async (req, res) => {
    if (res.locals.authorised) {
        if (!res.locals.id) {
            res.status(400).json({ status: "error", message: "Not logged in." });
            logger.error(`IP ${req.ip} made an authentication check request with a valid token, but no id!`);
            return;
        }
        logger.debug(`Getting authentication username for ${res.locals.id}:`)
        Auth.findOne({ uuid: sanitize(res.locals.id) })
            .then((user: any) => {
                if (user) {
                    res.status(200).json({
                        status: "ok",
                        name: user.username
                    });
                    return;
                } else {
                    res.status(400).json({
                        status: "error",
                        message: "UID not registered"
                    })
                    logger.error(`Auth user ${res.locals.id} is not registered`);
                    return;
                }
            })
            .catch((err: any) => {
                res.status(500).json({
                    status: "error",
                    message: "UID not registered"
                })
                logger.warn(`Could not find auth name for ${res.locals.id}`)
                return;
            })
    } else {
        res.status(400).json({ status: "error", message: "Not logged in." })
        logger.warn(`IP ${req.ip} made a request for a username without being logged in.`);
    }
});

router.get('/loggedIn', async (req, res) => {
    if (res.locals.authorised) {
        res.status(200).json({ status: "ok", loggedIn: true })
        logger.debug(`UID: ${res.locals.id} is logged in!`);
    } else {
        res.status(200).json({ status: "ok", loggedIn: false })
        logger.debug(`IP: ${req.ip} is not logged in.`);
    }
})


export const loginAPI = router;
