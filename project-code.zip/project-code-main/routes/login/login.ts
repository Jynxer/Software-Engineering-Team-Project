import express = require('express');
import sanitize = require('mongo-sanitize');
import axios from 'axios';

import { v4 as uuidv4 } from 'uuid';

import { getUserModel, UserConnection } from '../../database/userdb';
import { getAuthModel, AuthConnection } from '../../database/authdb';
import { IUser } from '../../database/Schema/user';
import { IAuth } from '../../database/Schema/auth';

import { loginAPI } from './loginAPI';

import supergroup = require('../supergroup.json');
import config = require('../../config.json');

import { genToken, getID, getIssuer } from "../../Middleware/jwtHandling";
import { logger } from "../../Middleware/loggingMiddleware";
import { jwtBlacklist } from "../../Middleware/jwtBlacklist";
import { jwtWhitelist } from "../../Middleware/jwtWhitelist";

const apiRouter: express.Router = express.Router();
const loginRouter: express.Router = express.Router();

const User = getUserModel(UserConnection);
const Auth = getAuthModel(AuthConnection);

async function registerTransaction(user: IUser, auth: IAuth) {
    let success = false;
    try {
        await auth.save()
        success = true;
        await user.save()
    } catch (err) {
        if (success) {
            await Auth.deleteOne({ uuid: auth.uuid })
        }
        throw err
    }
}

apiRouter.use('/loginAPI', loginAPI);

apiRouter.post("/register", (req, res) => {
    jwtBlacklist.purgeAllOld(); // clear blacklist of invalid tokens.
    jwtWhitelist.purgeAllOld(); // clear whitelist of invalid tokens.

    interface UserInfo extends IUser, IAuth {
    }

    let info: UserInfo = req.body;

    // Ensures the request has a password, username and email
    if (!(info.username && info.password && info.email)) {
        res.status(400).json({
            status: "missingFields",
            message: "Not all information provided"
        });
        logger.warn(`IP: ${req.ip} made a register request without the requisite information.`);
        return;
    }

    const passwordLenMin: number = 8;
    const passwordLenMax: number = 64;

    // Checks password length (not complexity) as per ncsc recommendation 
    // Length max as bcrypt doesn't allow for big passwords
    if (info.password.length < passwordLenMin || info.password.length > passwordLenMax) {
        res.status(400).json({
            status: "badPasswordLength",
            message: "Bad password"
        });
        logger.warn(`IP: ${req.ip} made a register request with a malformed password.`);
        return;
    }

    // Checks if email is valid with basic email regex
    const emailPattern: RegExp = new RegExp(/^[^@ \t\r\n]+@[^@ \t\r\n]+\.[^@ \t\r\n]+/);
    if (!emailPattern.test(info.email)) {
        res.status(400).json({
            status: "badEmail",
            message: "Bad email"
        });
        logger.warn(`IP: ${req.ip} made a register request with a malformed email address.`);
        return;
    }

    // Creates new user
    let uuid: string = sanitize(uuidv4()); // sanitize to ensure the uuid stored is equal to the sanitized uuid later
    info.username = sanitize(info.username);

    let newAuth = new Auth({
        uuid: uuid,
        username: info.username,
        password: sanitize(info.password),
    });

    let fullName: string = sanitize(info.fullName);

    let newUser = new User({
        uuid: uuid,
        username: info.username,
        fullName: fullName,
        email: sanitize(info.email),
    });

    // Stores user in database and sends back appropriate response back
    registerTransaction(newUser, newAuth).then(() => {
        const token: string = genToken(uuid);
        res.set('Authorization', token);

        res.status(200).json({
            status: "ok",
            token: token
        });

        logger.info(`User : '${sanitize(info.username)}' has logged in.`);
    }).catch((err: Error) => {
        //Issue on registering
        res.status(400).json({
            status: "repeatCredentials",
            message: "could not register"
        });
        logger.warn(`User : ${sanitize(info.username)} could not be registered from IP ${req.ip}: ${err}`);
    })
});

apiRouter.post('/logout', (req, res) => {
    if (res.locals.authorised) {

        if (!res.locals.id) {
            logger.error(`IP ${req.ip} authenticated without a uuid!`);
            res.status(401).json({ status: "error", message: "Malformed request!" });
            return;
        }

        logger.info(`ID '${res.locals.id}' logged out.`);

        getIssuer(<string>req.header("Authorization"))
            .then(issuer => {

                if (issuer == config.supergroupID) {
                    jwtBlacklist.addItem(<string>req.header("Authorization"));
                } else {
                    jwtWhitelist.addItem(<string>req.header("Authorization"))
                }

                res.status(200).json({ status: "ok" });
                return;
            })
            .catch(err => {
                logger.error(`Could not get issuer for a verified token: ${<string>req.header("Authorization")}: ${err}`)
                res.status(400).json({
                    status: "error",
                    message: "Bad request - invalid token."
                })
                return;
            })

    } else {
        res.status(400).json({ status: "error", message: "Bad request - not logged in!" });
        logger.warn(`IP '${req.ip}' attempted to log out ID '${res.locals.id}' without being logged in.`);
    }
});

loginRouter.post('/login', (req, res) => {
    jwtBlacklist.purgeAllOld(); // clear blacklist of invalid tokens.
    jwtWhitelist.purgeAllOld(); // clear whitelist of invalid tokens.

    if (res.locals.authorised) { // already logged in - redirect to home
        if (res.locals.id) {
            logger.warn(`ID '${res.locals.id}' is already logged in.`);
        } else {
            logger.error(`IP '${req.ip}' is authenticated without an id!`);
        }

        res.redirect('/');
        return;
    }

    let username: string = sanitize(req.body.username);
    let password: string = sanitize(req.body.password);

    let id: number = config.supergroupID;

    if (sanitize(req.body.journalId) && username && password) {
        try {
            id = <number>Number(sanitize(req.body.journalId))
            if (!Number.isInteger(id) || !supergroup.hasOwnProperty(id)) {
                logger.warn(`IP ${req.ip} attempted to log in to an unknown supergroup id: ${req.body.journalId}`);
                res.status(400).json({
                    status: "error",
                    message: "bad journalId"
                })
            }
        } catch (err: any) {
            logger.warn(`IP ${req.ip} attempted to log in to an unknown supergroup id: ${req.body.journalId}`);
            res.status(400).json({
                status: "error",
                message: "bad journalId"
            })
        }
    }

    if (username && password) {
        if (id != config.supergroupID) { //foreign user
            const journal = (<supergroupInfo>supergroup)[id]
            const queryUrl = `${journal.url.replace(/\/+$/, '')}/v1/login`

            logger.debug(`sending post to ${queryUrl}`)

            axios.post(queryUrl, {
                username: username,
                password: password
            }, {timeout: 1000})
                .then(async data => {
                    logger.debug(`Data recieved: ${Object.keys(data.data)}`)
                    const regex = new RegExp(/.*token.*/, 'i');
                    let token: string | undefined = undefined;
                    for (let key of Object.keys(data.data)) {
                        if (regex.test(key)) {
                            token = data.data[key]
                            break;
                        }
                    }
                    logger.debug(`Token: ${token}`)

                    if (!token) {
                        res.status(500).json({
                            status: "error",
                            message: `${journal.name} did not respond with a token`
                        })
                        return;
                    }

                    try {
                        const uid = await getID(token)
                        const tokenJournalId = await getIssuer(token)
                        logger.debug(`UUID = ${uid}`);
                        logger.debug(`Issuer = ${tokenJournalId}`)

                        const user = await User.exists({ uuid: uid, journalId: id });

                        if (user != null) { // found a user already saved in local db
                            res.set('Authorization', token);

                            res.status(200).json({
                                status: "ok",
                                token: token
                            });
                            jwtWhitelist.addItem(token);
                            return;
                        } else { // needs to register user
                            const queryUrl = `${journal.url.replace(/\/+$/, '')}/v1/users/${uid}`

                            axios.get(queryUrl, {
                                headers: {
                                    'Authorization': token
                                },
                                timeout: 1000
                            })
                                .then(data => {
                                    if (!data.data.user) {
                                        res.status(500).json({
                                            status: "error",
                                            message: `User request from ${journal.name} did not contain a user`
                                        })
                                        return;
                                    }
                                    const userData = data.data.user;

                                    let userObject: Record<string, any> = {}
                                    const uuidRegex = new RegExp(/.*uid.*/, 'i');
                                    const usernameRegex = new RegExp(/.*user.*/, 'i');
                                    const journalIdRegex = new RegExp(/.*journal.*/, 'i');
                                    const fullNameRegex = new RegExp(/.*full.*/, 'i');
                                    const profilePicRegex = new RegExp(/.*pic.*/, 'i');
                                    const emailRegex = new RegExp(/.*email.*/, 'i');

                                    Object.keys(userData).forEach(key => {
                                        if (uuidRegex.test(key)) { // uuid
                                            userObject.uuid = userData[key]
                                            if (uid != userData[key]) {
                                                logger.error(`UID provided by ${journal.name} did not match the uid requested!`)
                                                res.status(500).json({
                                                    status: "error",
                                                    message: `${journal.name} did not provide the user data for the same uuid`
                                                })
                                                return;
                                            }
                                        } else if (usernameRegex.test(key)) { // username
                                            userObject.username = userData[key]
                                        } else if (emailRegex.test(key)) { // email
                                            userObject.email = userData[key]
                                        } else if (journalIdRegex.test(key)) { // journal
                                            userObject.journalId = userData[key]
                                        } else if (fullNameRegex.test(key)) { // full name
                                            userObject.fullName = userData[key]
                                        } else if (profilePicRegex.test(key)) { // profile picture
                                            userObject.profilePicture = userData[key]
                                        } else {
                                            logger.debug(`Key unknown: ${key}`);
                                        }
                                    })

                                    try {

                                        let newUser = new User({
                                            uuid : userObject.uuid,
                                            username : userObject.username,
                                            email : userObject.email,
                                            journalId : userObject.journalId,
                                            fullName : userObject.fullName,
                                            profilePicture : userObject.profilePicture
                                        })

                                        if (!newUser.journalId) {
                                            newUser.journalId = id;
                                        }

                                        if (!newUser.profilePicture) {
                                            newUser.profilePicture = 'https://material.angular.io/assets/img/examples/shiba2.jpg';
                                        }

                                        newUser.save()
                                            .then(_ => {
                                                logger.info(`Registered foreign user ${newUser.username} from journal ${journal.name}`)
                                                res.status(200).json({
                                                    status: "ok",
                                                    token: token
                                                })
                                                jwtWhitelist.addItem(<string>token);
                                                return;
                                            })
                                            .catch((err: any) => {
                                                logger.warn(`Could not save foreign user ${newUser.username} from ${journal.name}: ${err}`)
                                                res.status(500).json({
                                                    status: "error",
                                                    message: "could not save user details"
                                                })
                                                return;
                                            })
                                    } catch (err: any) {
                                        logger.error(`Could not create a user from the response from ${journal.name} for user ${uid}`)
                                        res.status(500).json({
                                            status: "error",
                                            message: `insufficient information from ${journal.name}`
                                        })
                                        return;
                                    }


                                })
                                .catch((err) => {
                                    let msg: string = ""
                                    if (err.response.data.message) {
                                        msg = err.response.data.message;
                                    } else {
                                        msg = err.response.data.error;
                                    }
                                    logger.error(`${journal.name} failed to provide details for user ${uid}: ${msg}`)
                                    res.status(err.response.status).json({
                                        status: "error",
                                        message: msg
                                    })
                                    return;
                                })

                        }

                    } catch (err: any) {
                        res.status(500).json({
                            status: "error",
                            message: `${journal.name} did not provide a token with a valid uuid`
                        })
                        return;
                    }
                })
                .catch((err: any) => {
                    console.log(err.response)
                    let msg: string = ""
                    if (err.response.data.message) {
                        msg = err.response.data.message;
                    } else {
                        msg = err.response.data.error;
                    }
                    logger.warn(`IP ${req.ip} encountered an error when communicating with ${journal.name}: ${msg}`);
                    res.status(err.response.status).json({
                        status: "error",
                        message: msg
                    })
                    return;
                })

        } else { //current user
            // Tries to find user based on username
            Auth.findOne({ username: username }, function (err: any, user: any) {
                // Failed to find user
                if (err) {
                    res.status(500).json({ status: "error", message: "invalidCredentials" });
                    logger.error(`Mongodb error for username search: ${err}`);
                    return;
                }
                if (!user) {
                    // Need to include delay avoiding user enumeration - possibly compare a random password?
                    res.status(401).json({ status: "error", message: "invalidCredentials" });
                    logger.warn(`IP '${req.ip}' made a login request to a user which couldn't be found: ${username}.`);
                    return;
                }

                // Checks passwords
                user.comparePassword(password, function (err: any, match: any) {
                    if (err || !match) {
                        if (err) {
                            logger.error(`Error checking password for IP '${req.ip}' when attempting to log in 
                        user '${username}'.`);
                        } else {
                            logger.warn(`IP '${req.ip}' made a login request for user '${username}' with the wrong
                         password`);
                            res.status(401).json({ status: "error", message: "invalidCredentials" });
                            return;
                        }
                        res.status(400).json({ status: "error", message: "unknown error" });
                        return;
                    }
                    // Everything was okay
                    const token: string = genToken(user.uuid);
                    res.set('Authorization', token);

                    res.status(200).json({
                        status: "ok",
                        token: token
                    });

                    logger.info(`User : '${username}' has logged in from '${req.ip}'.`);
                });
            });
        }
        return;
    }

    res.status(400).json({ status: "error", message: "missingFields" });
    logger.warn(`IP '${req.ip}' made an invalid request to ${req.originalUrl} - 
    missing username or password fields.`);
});

interface supergroupInfo {
    [key: number]: { name: string, url: string }
}

export const login = loginRouter;
export const registerLogout = apiRouter;
