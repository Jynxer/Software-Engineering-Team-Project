import express = require('express');
import expressFileUpload = require('express-fileupload');
import sanitize = require('mongo-sanitize');
import { v4 as uuidv4 } from 'uuid';

import {uploadExpressFiles} from '../database/filesystem';
import {logger} from '../Middleware/loggingMiddleware';
import { ISubmission } from '../interfaces/submissionInterface';
import content = require('../database/filedb');
import { SubmissionStages } from './permission/submissionStages';
import { sendError } from '../interfaces/permissions';
import { findOneEdit } from '../database/permissionChecks/submission';

const Submission = content.getSubmissionModel(content.contentConnection);
const File = content.getFileModel(content.contentConnection);


const router: express.Router = express.Router();


router.post('/upload', async (req, res) => {

    if (!res.locals.authorised) {
        // not logged in - can't upload file
        res.redirect('/');
        logger.warn(`Upload attempt from ${req.ip} failed - not logged in`);
        return;
    }
    // if no files are uploaded
    if (req.files == undefined) {
        logger.warn(`Upload attempt from ${req.ip} failed - no files found`);
        res.status(400).json({
            status: "error",
            message: "no file found"
        });
        return;
    }

    let submissionTitle: string = sanitize(req.body.title);
    let submissionDescription: string = sanitize(req.body.description);
    let submissionUuid: string = sanitize(uuidv4());

    let files: expressFileUpload.FileArray = req.files;
    let currentAuthorUuid = sanitize(res.locals.id);

    let newSubmission = new Submission({
        uuid: submissionUuid,
        kind: 'original',
        authorUuid: currentAuthorUuid,
        title: submissionTitle,
        description: submissionDescription,
        submissionDate: Date.now()
    });

    // Adds the files   
    
  
    newSubmission.save()
    .then(submission => uploadExpressFiles(files, submissionUuid, (<ISubmission>submission).versionNumber))
    .then(files =>  File.insertMany(files))
    .then(() => {
        logger.info(`User: ${res.locals.id} successfully uploaded file/s.`);
        res.status(202).json({
            status: "ok",
            uuid :submissionUuid,
        });
    })
    .catch(err => {
        logger.error(`Failed to upload files: ${err}`);
        res.status(400).json({
            status: "error",
            message: "error uploading file"
        });
    })
})

// Used to reuplaod a submisison
// Idea for versions came from group 22, though this was just the idea and not the implimentation  of it 
router.post('/reupload', async (req, res) => {
   
    if (!res.locals.authorised) {
        // not logged in - can't upload file
        res.redirect('/');
        logger.warn(`Upload attempt from ${req.ip} failed - not logged in`);
        return;
    }

    // if no files are uploaded
    if (req.files == undefined) {
        logger.warn(`Upload attempt from ${req.ip} failed - no files found`);
        res.status(400).json({
            status: "error",
            message: "no file found"
        });
        return;
    }

    let submissionUuid: string = sanitize(req.body.uuid);
    let files: expressFileUpload.FileArray = req.files;
    let authorUuid: string = sanitize(res.locals.id);

    // Ensures we can edit, we also check if we if the stage is 
    findOneEdit({uuid: submissionUuid}, authorUuid)
    .then(submission => {
        // Reuploading a published submission takes it back to reviewing
        if (submission.submissionStage == SubmissionStages.Published) {
            return SubmissionStages.Reviewing;
        }
        // Else return current stage
        return submission.submissionStage;
    })
    .then(newStage => {
        let update:any = {
            submissionStage: newStage, 
            $inc: {versionNumber: 1}
        }

        if (req.body.title) {
            update.title = req.body.title;
        }

        if (req.body.description) {
            update.description = req.body.description;
        }

        return Submission.findOneAndUpdate({uuid: submissionUuid}, update);
    })
    .then(async newSubmission => uploadExpressFiles(files, submissionUuid, (<ISubmission>newSubmission).versionNumber + 1))
        .then(files => File.insertMany(files))
        .then(() => {
            logger.info(`User: ${res.locals.id} successfully uploaded file/s.`);
            res.status(202).json({
                status: "ok",
                uuid: submissionUuid
            });
    }).catch(err => sendError(err, 'reuploading', res, `submissionUuid: ${submissionUuid}`))
});

export const upload = router;
