import express = require('express');
import sanitize = require('mongo-sanitize');
import { v4 as uuidv4 } from 'uuid';

import {logger} from '../Middleware/loggingMiddleware';
import { CommentStages, ICommentInfo, ICommentJournal } from '../interfaces/commentInterface';
import content = require('../database/filedb');
import { SubmissionStages } from './permission/submissionStages';
import { sendError } from '../interfaces/permissions';
import { commentUpdateOne, getCommentStage } from '../database/permissionChecks/comment';
import { findOneAccess } from '../database/permissionChecks/submission';
import { IComment } from '../database/Schema/comment';

const Comment = content.getCommentModel(content.contentConnection);
const File = content.getFileModel(content.contentConnection);


const router: express.Router = express.Router();

// Adds a comment to the database
router.post('/comment', async (req, res) => {
    let info: ICommentInfo = <ICommentInfo>req.body;

    if (!res.locals.id) {
        // comment contents empty
        res.status(401).json({
            status: "error",
            message: "can't comment  whilst not logged in"
        });
        logger.warn(`Upload attempt from un authenticated user`);
        return;
    }

    if (info.contents.length == 0) {
        // comment contents empty
        res.status(400).json({
            status: "error",
            message: "contents empty"
        });
        logger.warn(`Upload attempt from ${res.locals.id} failed - no comment`);
        return;
    }

    let currentAuthorUuid: string = sanitize(res.locals.id);
    let submissionUuid:string = sanitize(info.submissionUuid);
    let pathStr:string = sanitize(info.path) ? <string> sanitize(info.path) : "";
    // Finds the find for the submission with the given path, submisison uuid and the found version number
    findOneAccess({uuid: submissionUuid}, currentAuthorUuid)
    .then(async submission => {

        if (!submission) {
            res.status(404).json({
                "status": "error",
                "message": "Failed to get submissions"
            })
        }

        
        // If the file doesn't exist  
        // Can only post on current submission
        if(!await File.exists({ submissionUuid: submissionUuid, path: pathStr, versionNumber: submission.versionNumber })) {
            res.json(404).json({
                "status":"error",
                "message": "File not found"
            });
            return;
        }
        
        let parentCommentUuid:string | undefined = sanitize(info.replyingTo);
        let commentStage: CommentStages | null;
        let version: number;


        if (parentCommentUuid) {
            // Find parent comment - can't be resolved (as these arent shown)
            let commentExists: any = await Comment.exists({ 
                uuid: parentCommentUuid,
                path: pathStr,
                submissionUuid: submissionUuid,
                resolved: false,
                });
            if (!commentExists) {
                res.status(401).json({
                    status: "error",
                    message: "Can't respond to comment which doesn't exist"
                });
                return;
            }
            // Get the parent comment
            let parentComment: any = await Comment.findOne({ uuid: parentCommentUuid });
            // We forbid a parent of a parent comment for now
            if (!parentComment || parentComment.parentComment) {
                res.status(401).json({
                    status: "error",
                    message: "Threads can only have a depth of 2 for now"
                });
                return;
            }

            // We set the stage and version of the parent (to allow for comments to reply to old versions?)
            // Can be changed however
            commentStage = (<IComment>parentComment).stage;
            version = (<IComment>parentComment).versionNumber;

        } else {

            // If the comment is a top level, we base the version and stage of the submission
            parentCommentUuid = undefined;
            commentStage = getCommentStage(<SubmissionStages>submission.submissionStage);
            version = submission.versionNumber;
            
            if (!commentStage) {
                logger.warn("Can't comment on unpublished submissions");
                res.status(400).json({
                    "status":"error",
                    "message":"Can't comment on submission"
                })
            }
        }

        let commentUuid: string = sanitize(uuidv4());
        let newComment = new Comment({
            uuid: commentUuid,
            authorUuid: currentAuthorUuid,
            path: pathStr,
            submissionUuid: submissionUuid,
            commentDate: Date.now(),
            line: sanitize(info.line),
            contents: sanitize(info.contents),
            parentComment: parentCommentUuid,
            stage: commentStage,
            versionNumber: version
        });

        newComment.save().then(async () => {
            logger.info(`Successfully uploaded comment from ${res.locals.id}`);
            logger.debug(`Comment = ${sanitize(info.contents)}`)
            res.status(202).json({
                status: "ok",
                uuid: commentUuid
            });
            return;
        }).catch((err: Error) => {
            // Issue happened saving comment - would need to get rid of err being returned
            res.status(400).json({
                status: "error",
                message: "Failed to save comment"
            });
            logger.error(`Error saving comment from user ${res.locals.id}: ${err.message}`)
        });
            
    }).catch(err => {
        sendError(err, 'comment - post', res, `submission: ${submissionUuid}`)
    })
});


// Gets all comments from file database
router.get('/:submission/comments/:path(*)', (req, res) => {
        
    let submissionUuid:string = sanitize(req.params.submission);
    let pathStr:string = '/' + sanitize(req.params.path);
    let version: number | null = req.query.version ? Number(sanitize(req.query.version)) : null
    let currentAuthorUuid: string = sanitize(res.locals.id);

    // May not work :(
    findOneAccess({ uuid: submissionUuid}, currentAuthorUuid)
        .then(async submission => {

            if (!version) {
                version = submission.versionNumber;
            }

            // Since we check if the file exists for a comment, no comments can exist on a non-existant submission
            Comment.find({
                path: pathStr,
                submissionUuid: submissionUuid,
                parentComment: { $exists: false },
                resolved: false,
                versionNumber: version,
                stage: getCommentStage(<SubmissionStages>submission.submissionStage)
            })
            .then(async (comments: any) => {
                let commentsJournal: ICommentJournal[][] = [];
                for (let parentComment of comments) {
                    let comment: any = parentComment;
                    let commentThread: ICommentJournal[] = [comment.format()];

                    // Only check if comment uuid (as child inherits mostly from parent)
                    if (await Comment.exists({ parentComment: parentComment.uuid })) {

                        // Get child comments of each top-level comment in order
                        let childComments = await Comment.find({ parentComment: parentComment.uuid, resolved: false }).sort({
                            commentDate: 1
                        })
                        for (let childComment of childComments) {
                            // Any as doesn't work otherwise
                            let subComment: any = childComment;
                            // We use SG formatting to remove line numbers here (not needed as replying)
                            commentThread.push(subComment.formatSG());
                        }
                    }
                    commentsJournal.push(commentThread);
                }
                res.json({
                    'status': 'ok',
                    'comments': commentsJournal
                })
            })
    }).catch(err => {
        sendError(err, 'file', res, `path: ${pathStr}, submission:${submissionUuid}`)
    })

});

// Fetches resolved comments
router.get('/:submission/resolved-comments/:path(*)', (req, res) => {
        
    let submissionUuid:string = sanitize(req.params.submission);
    let pathStr:string = '/' + sanitize(req.params.path);
    let version: number | null = req.query.version ? Number(sanitize(req.query.version)) : null
    let currentAuthorUuid: string = sanitize(res.locals.id);

    // May not work :(
    findOneAccess({ uuid: submissionUuid}, currentAuthorUuid)
        .then(async submission => {

            if (!version) {
                version = submission.versionNumber;
            }

            // Since we check if the file exists for a comment, no comments can exist on a non-existant submission
            Comment.find({
                path: pathStr,
                submissionUuid: submissionUuid,
                parentComment: { $exists: false },
                resolved: true,
                versionNumber: version,
                stage: getCommentStage(<SubmissionStages>submission.submissionStage)
            })
            .then(async (comments: any) => {
                let commentsJournal: ICommentJournal[][] = [];
                for (let parentComment of comments) {
                    let comment: any = parentComment;
                    let commentThread: ICommentJournal[] = [comment.format()];

                    // Only check if comment uuid (as child inherits mostly from parent)
                    if (await Comment.exists({ parentComment: parentComment.uuid })) {

                        // Get child comments of each top-level comment in order
                        let childComments = await Comment.find({ parentComment: parentComment.uuid}).sort({
                            commentDate: 1
                        })
                        for (let childComment of childComments) {
                            // Any as doesn't work otherwise
                            let subComment: any = childComment;
                            // We use SG formatting to remove line numbers here (not needed as replying)
                            commentThread.push(subComment.formatSG());
                        }
                    }
                    commentsJournal.push(commentThread);
                }
                res.json({
                    'status': 'ok',
                    'comments': commentsJournal
                })
            })
    }).catch(err => {
        sendError(err, 'file', res, `path: ${pathStr}, submission:${submissionUuid}`)
    })

});

// Used to resolve comment threads
router.post('/comment/resolve', async (req, res) => {
    let commentUuid: string = sanitize(req.body.uuid);

    // Set resolved to true
    commentUpdateOne({ uuid: commentUuid, resolved: false }, { resolved: true }, res.locals.id)
        .then(comment => {
            res.status(200).json({
                "status": "ok",
            });
        }).catch(err => {
            sendError(err, 'comment - resolve', res, commentUuid);
        })
});

// Used to resolve comment threads
router.post('/comment/unresolve', async (req, res) => {
    let commentUuid: string = sanitize(req.body.uuid);

    // Set resolved to true
    commentUpdateOne({ uuid: commentUuid, resolved: true }, { resolved: false }, res.locals.id)
        .then(() => {
            res.status(200).json({
                "status": "ok",
            });
        }).catch(err => {
            sendError(err, 'comment - unresolve', res, commentUuid);
        })
});


export const comments = router;
