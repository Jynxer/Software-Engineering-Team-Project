// import express = require('express');
// import sanitize = require('mongo-sanitize');
// import yazl = require('yazl');

// import content = require('../database/filedb');
// import {  } from "yazl";
// import { ISubmission } from '../interfaces/submissionInterface';
// import { IFile } from '../database/Schema/file';

// const Submission = content.getSubmissionModel(content.contentConnection);
// const File = content.getFileModel(content.contentConnection);
// const Comment = content.getCommentModel(content.contentConnection);



// // Returns the submission uuid if the version is set to null, else returns version
// async function getVersion(submissionUuid: string,  version: number | null):Promise<number> {
//     if (version) {
//         return new Promise<number>((res, rej) => {
//             res(version);
//         })
//     }
//     return Submission.findOne({uuid: submissionUuid})
//     .then(submission => {return (<ISubmission>submission).versionNumber})
// }

// /**
//  * Returns the file for a given version number, path and submission
//  * @param submissionUuid of the file
//  * @param path of the file
//  * @param version to find of the submission
//  * @returns the uuid if it can find one
//  */
// export async function fetchFile(submissionUuid: string, path:string, version: number | null):Promise<IFile> {

//     return await getVersion(submissionUuid, version).then(async versionNum => {
//         return await File.findOne({ submissionUuid: submissionUuid, path: path, versionNumber: <number>versionNum})
//         .then(file => {return <IFile>file})
//    })
// }