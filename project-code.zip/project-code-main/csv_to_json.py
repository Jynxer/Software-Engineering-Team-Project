#!/usr/bin/env python3

import csv
import sys
import os
import json

def main(filename):
    obj = {}
    with open(filename) as csv_file:
        reader = csv.reader(csv_file, delimiter=",")
        _ = reader.__next__() # headers
        for row in reader:
            data = {}
            data['name'] = row[1]
            data['url'] = row[2]
            obj[row[0]] = data
    
    prefix = filename.split('.')[0]
    json_path = f"{prefix}.json"

    if os.path.exists(json_path):
        os.remove(json_path)

    with open(json_path, "w") as json_file:
        json.dump(obj, json_file)


def print_usage():
    print(f"Usage: {sys.argv[0]} <filename.csv>")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print_usage()
    else:
        main(sys.argv[1])