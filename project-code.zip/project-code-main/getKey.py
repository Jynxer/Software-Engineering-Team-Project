#!/usr/bin/env python3
# Script to parse from a json file
# @author 150000946
import json
import sys

def main(json_file, keys):
    try:
        with open(json_file) as file:
            data = json.load(file)

            for k in keys:
                print(data.get(k))
    except Exception as e:
        sys.exit(-1)

def print_usage():
    print("Usage: <jsonFile> [keys to search]")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print_usage()
        sys.exit(-1)
    else:
        keys = []
        for i in range(2, len(sys.argv)):
            keys.append(sys.argv[i])
        main(sys.argv[1], keys)
