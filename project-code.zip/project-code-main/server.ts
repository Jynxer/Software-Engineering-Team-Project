// To stop text encoder issue on lab machine
global.TextEncoder = require("util").TextEncoder;
global.TextDecoder = require("util").TextDecoder;

import express = require('express');
import path = require('path');
import readline = require('readline');
import EventEmitter = require('events');
import expressFileUpload = require('express-fileupload');
import config = require('./config.json');
import bodyParser = require('body-parser');

import sanitize = require("mongo-sanitize");
import { UserConnection, getUserModel, modelName } from "./database/userdb";
import { AuthConnection, getAuthModel } from "./database/authdb";
import { v4 as uuidv4 } from 'uuid';
import { Role } from "./routes/permission/roles";
import { IUser } from "./database/Schema/user";

import { logger } from './Middleware/loggingMiddleware';
import { JWTMiddleware } from "./Middleware/jwtMiddleware";
import { LoggingMiddleware } from "./Middleware/loggingMiddleware";
import { routes } from './routes/routes'


declare var __dirname: string;

// Interactive command setup
const unknownMsg: string = "Unknown command:";

const rl: readline.Interface = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

/**
 * Handles interactive command parsing, emits corresponding correct events.
 */
function commandPrompt(): void {
    rl.question("", (answer: string) => {
        const args: string[] = answer.toLowerCase().split(/ +/);
        let command: string = args.shift() as string;

        let commands = config.commands;

        let keys = commands.reduce((previous: any[], current, index) => {
            let key: string = Object.keys(commands[index])[0];
            let arr: string[] = (commands as any)[index][key];

            for (let i: number = 0; i < arr.length; i++) {
                if (arr[i] === command) {
                    previous.push(key);
                    break;
                }
            }
            return previous;
        }, []);

        for (let i: number = 0; i < keys.length; i++) {
            command = keys[i];
            emitter.emit(command, args);
        }

        if (keys.length == 0) { // command not recognised.
            console.log(unknownMsg);
            emitter.emit("help", args);
        }

        commandPrompt(); // prepare another command
    });
}

/**
 * Cleanup on interrupt signal
 */
rl.on('SIGINT', () => {
    exitHandler();
});

// Event handling
class Emitter extends EventEmitter {
}

const emitter: Emitter = new Emitter();

/**
 * Exit command
 */
emitter.on("exit", () => {
    exitHandler();
})

emitter.on("reload", () => {
    process.exit(config.reloadExitCode);
})

/**
 * Help command
 */
emitter.on("help", () => {
    let str: string = "";
    config.commands.forEach(cmd => {
        if (str.length > 0) {
            str += ", ";
        }
        str += Object.keys(cmd)[0];
    });
    process.stdout.write("Commands: <");
    process.stdout.write(str);
    process.stdout.write(">");
});

/**
 * Cleans up and quits the process.
 */
function exitHandler(): void {
    process.stdout.write("Exiting...");
    process.exit(config.safeExitCode);
}

// Database superuser

AuthConnection.useDb(modelName);
const User = getUserModel(UserConnection);
const Auth = getAuthModel(AuthConnection);

try {
    User.exists({ username: { $regex: /.*admin.*/, $options: "i" }, role: "Admin" }, async (err, exists) => {
        if (err) {
            throw Error(`${err}`);
        }

        if (!exists) {
            const uid = sanitize(uuidv4());
            const suAuth = new Auth({
                uuid: uid,
                username: sanitize(config.suUsername),
                password: sanitize(config.suPassword)
            });

            const suUser = new User({
                uuid: uid,
                username: "Admin",
                fullName: "Admin",
                email: config.suEmail,
                role: Role.Admin
            });

            let success = false;
            try {
                await suAuth.save();
                success = true;
                await suUser.save();
                logger.info(`Registered ${config.suUsername}`);
                console.log(`Password: ${config.suPassword}`);
            } catch (err) {
                logger.error(`Could not generate super user: ${err}`);
                if (success) {
                    await Auth.deleteOne({ uuid: suAuth.uuid });
                }
            }
        } else {
            User.findOne({ username: { $regex: /.*admin.*/, $options: "i" } })
                .exec(async (err: any, user: IUser) => {
                    if (err) {
                        logger.error(`Could not find admin IUser: ${err}`);
                        return;
                    } else if (!user) {
                        logger.error("Could not find admin IUser");
                        return;
                    }

                    const uid = user.uuid;

                    const old = await Auth.findOne({ uuid: uid });
                    old.username = sanitize(config.suUsername);
                    old.password = sanitize(config.suPassword);
                    await old.save();
                    console.log(`Admin username: ${config.suUsername}\nAdmin password: ${config.suPassword}`);
                });
        }
    })
} catch (err) {
    logger.error(`Error initialising super user: ${err}`);
}


// Server setup
const app = express();
const port: number = config.port;

app.set('trust proxy', true);

app.use(LoggingMiddleware);

app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json());
app.use(expressFileUpload());
app.use(express.static(path.join(__dirname, 'public')));

app.use(JWTMiddleware);

app.listen(port, "", 1024, () => {
    commandPrompt(); //interactive commands
    logger.info(`Server is running on port ${port}.`);
});

/**
 * Explicit endpoint for favicon.
 */
app.get('/favicon.ico', (req, res) => {
    res.sendFile(__dirname + '/public/favicon.ico');
})

app.use('/', routes);

/**
 * Redirect all other requests to angular project.
 */
app.get('/*', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

